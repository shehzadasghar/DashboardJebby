
import React , {useState,useEffect} from 'react'; 
import "./Showallemployee.css"
import {Link} from "react-router-dom"
import Modal from "react-modal";
import {getAllRoles} from "../../actions/Allrolesaction"
import {getAllEmployee} from "../../actions/Allemployees"
import {connect} from "react-redux"
import FullPageLoader from "../fullpageloader/fullPageLoader";
const config = require('../../helpers/config.json');
  
const ShowAllEmployee = (props) => { 
    const [load,setload]=useState(false)
    const [ExpensemodalIsOpen, setExpenseModalIsOpen] = useState(false);
    useEffect(() => {
        loadGetRoles()
        loadGetEmployees()
      },[]);
      const loadGetRoles = async () => {
        await props.getAllRoles()
        return null;
      }
      const loadGetEmployees = async () => {
        await props.getAllEmployee()
        return null;
      }
    const [employeeName,setemployeeName]=useState("")
    const [location,setlocation]=useState()
    const [phoneNumber,setphoneNumber]=useState("")
    const [cnic,setcnic]=useState("")
    const [address,setaddress]=useState("")
    const [referenceName,setreferenceName]=useState("")
    const [roleId,setroleId]=useState("")
    const createEmployee = async() =>{
        setload(true)
       await fetch(`${config['baseUrl']}/employees/create`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json',"jwt_token":localStorage.getItem("token") },
            body: JSON.stringify({
                "employeeName":employeeName,
                 "location":location,
                  "distributionId":localStorage.getItem("disid"),
                  "phoneNumber":phoneNumber,
                  "cnic":cnic,
                  "address":address,
                  "referenceName":referenceName,
                  "roleId":Number(roleId)
            })
        })
        .then(res => {
            console.log("res aqib", res)
            if (res.status !== 200) {
                alert("Some thing went wrong...");
            }
            return res.json();
        })
        .then((response) => {
            console.log("pppppp", response);
            if(response.message=="Employee Created"){
                window.location = "/employees"
            }
            else{
                alert("Something went wrong..")
            }
            setload(false)

        }).catch((error) => {
            console.log(error)
            alert("Please Check Your Internet Connection...")
            setload(false)
        })
    }
 
return ( 
      <>
      <div className="container my-5">
            <div className="row">
                  <div className="col-md-6">
                        <h1>All Employees</h1>
                  </div>
                  <div className="col-md-6 text-lg-right text-md-right mt-2">
                  <button className='border-0 rounded py-2 px-5  btnorderbookersub' onClick={() => setExpenseModalIsOpen(true)} >Add New Employee</button>
                  </div>
            </div>
            <div className='bg-white rounded shadow-lg p-lg-5 p-3 my-3'>
              <div style={{overflow:"auto",maxHeight:"500px"}}>
            <table className='table border-0  w-100' >
            <tr className='border-0 table-secondary'>
                   <th style={{border:"1px solid black"}}>Date & Time</th>
                   <th style={{border:"1px solid black"}}>Name</th>
                   <th style={{border:"1px solid black"}}>Location</th>
                   <th style={{border:"1px solid black"}}>Number</th>
                   <th style={{border:"1px solid black"}}>CNIC</th>
                   <th style={{border:"1px solid black"}}>Address</th>
                   <th style={{border:"1px solid black"}}>reference</th>
                   <th style={{border:"1px solid black"}}>Role</th>
               </tr>
  {
                  props.allemployeeReducer&&props.allemployeeReducer.allemployee&&props.allemployeeReducer.allemployee.length>0?props.allemployeeReducer.allemployee.map(val=>(
                    <tr>
                    <td style={{border:"1px solid black"}}>{`${val.createdAt.split("T")[0]} ${val.createdAt.split("T")[1].split(".")[0]}`}</td>
                    <td style={{border:"1px solid black"}}>{val.employeeName}</td>
                    <td style={{border:"1px solid black"}}>{val.location}</td>
                    <td style={{border:"1px solid black"}}>{val.phoneNumber}</td>
                    <td style={{border:"1px solid black"}}>{val.cnic}</td>
                    <td style={{border:"1px solid black"}}>{val.address}</td>
                    <td style={{border:"1px solid black"}}>{val.referenceName}</td>
                  {
                    val.Roles&&val.Roles.length>0?val.Roles.map(role=>(
                      <td style={{border:"1px solid black"}}>{role.roleName}</td>
                    )):""
                  }
                </tr>
                  )):"No Employee Found"
              }
</table>
</div>
            </div>
            {props.allemployeeReducer.loading == true ? (
                    <></>
                  ) : (
                    <FullPageLoader />
                  )}
                    {load == false ? (
                    <></>
                  ) : (
                    <FullPageLoader />
                  )}
      </div>


      <Modal
                isOpen={ExpensemodalIsOpen}
                onRequestClose={() => setExpenseModalIsOpen(false)}
                style={{
                  overlay: {
                    position: "fixed",
                    top: 0,
                    left: 0,
                    right: 0,
                    bottom: 0,
                    backgroundColor: "rgba(0,0,0,0.4)",
                    zIndex: "1",
                  },
                  content: {
                    position: "absolute",
                    margin: "0 auto",
                    width: "650px",
                    height: "530px",
                    top: "70px",
                    left: "0",
                    right: "0",
                    bottom: "100px",
                    border: "1px solid #ccc",
                    background: "#fff",
                    borderRadius: "4px",
                    outline: "none",
                    padding: "20px",
                    boxShadow: "0 0 5px 5px #f2f2f2",
                    borderRadius: "20px",
                    background: "#fff",
                    border: "1px solid #fff",
                  },
                }}
              >
                  <div className="row">
                      <div className="col-md-12 text-center">
                          <h3><strong>Add Employee</strong></h3>
                      </div>
                  </div>
                <div className="row mt-4">
<div className="col-md-6">
    <label htmlFor=""><strong>Name</strong></label>
    <input type="text" onChange={(e)=>setemployeeName(e.target.value)} className='form-control w-100' placeholder='Name' />
</div>
<div className="col-md-6">
    <label htmlFor=""><strong>Location</strong></label>
    <input type="text" onChange={(e)=>setlocation(e.target.value)} className='form-control w-100' placeholder='Location' />
</div>
                </div>
                <div className="row mt-4">
                <div className="col-md-6">
    <label htmlFor=""><strong>Address</strong></label>
    <input type="text" onChange={(e)=>setaddress(e.target.value)} className='form-control w-100' placeholder='Address' />
</div>
<div className="col-md-6">
    <label htmlFor=""><strong>Phone Number</strong></label>
    <input type="number" onChange={(e)=>setphoneNumber(e.target.value)} className='form-control w-100' placeholder='Phone Number' />
</div>
                </div>
                <div className="row mt-4">
                <div className="col-md-6">
    <label htmlFor=""><strong>CNIC</strong></label>
    <input type="text" onChange={(e)=>setcnic(e.target.value)} className='form-control w-100' placeholder='CNIC' />
</div>
<div className="col-md-6">
    <label htmlFor=""><strong>Reference Name</strong></label>
    <input type="text" onChange={(e)=>setreferenceName(e.target.value)} className='form-control w-100' placeholder='Reference Name' />
</div>
                </div>
                <div className="row mt-4">
                <div className="col-md-6">
    <label htmlFor=""><strong>Role</strong></label>
    <select className='form-control w-100'
     onKeyPress={(e) => {
      if (e.key === "Enter") {
        createEmployee();
      }
    }}
    onChange={(e)=>setroleId(e.target.value)}>
        <option value="" selected>--Select--</option>
        {
          props.allrolesReducer.allroles&&props.allrolesReducer.allroles.roles&&props.allrolesReducer.allroles.roles.length>0?props.allrolesReducer.allroles.roles.map(value=>(
         <option value={`${value.id!==null&&value.id!==undefined&&value.id!==""?value.id:""}`}>{`${value.roleName!==null&&value.roleName!==undefined&&value.roleName!==""?value.roleName:""}`}</option>
            )):""
        }
    </select>
</div>
                </div>
                <div className="row mt-4">
                    <div className="col-md-12 text-center">
                    <button className='border-0 rounded py-2 px-5  btnorderbookersub' onClick={() => createEmployee()} ><strong>Add</strong></button>
                    </div>
                </div>
              </Modal>
      </>
); 
} 

const mapStateToProps = (state) => ({
    allrolesReducer: state.allrolesReducer,
    allemployeeReducer: state.allemployeeReducer,
  });
  
  const mapDispatchToProps = (dispatch) => ({
    getAllRoles: () => dispatch(getAllRoles()),
    getAllEmployee: () => dispatch(getAllEmployee()),
  });
  export default connect(
    mapStateToProps,
    mapDispatchToProps
  )(ShowAllEmployee);