import React from 'react';
import "./Registration.css"
import {Link} from "react-router-dom"
import { useState } from 'react';
import FullPageLoader from "../fullpageloader/fullPageLoader";
const config = require('../../helpers/config.json');

const Registration = () => {
    const [load,setload]=useState(false)
    const [distributorName,setdistributorName]=useState("")
    const [location,setlocation]=useState("")
    const [CompanyName,setCompanyName]=useState("")
    const [userName,setuserName]=useState("")
    const [password,setpassword]=useState("")
    const [conpassword,setconpassword]=useState("")
    const register = async() =>{
        if(distributorName==""){
            alert("Enter Distribution Name...")
        }
        else if(location==""){
            alert("Enter Location...")
        }
        else if(CompanyName==""){
            alert("Enter Company Name...")
        }
        else if(userName==""){
            alert("Enter User Name...")
        }
        else if(password==""){
            alert("Enter Password...")
        }
        else if(conpassword==""){
            alert("Enter Confirm Password...")
        }
        else if(password!==conpassword){
            alert("Confirm Password Not Matched...")
        }
        else{
        setload(true)
        await fetch(`${config['baseUrl']}/distribution/createDistribution`, {
             method: 'POST',
             headers: { 'Content-Type': 'application/json' },
             body: JSON.stringify({
                 "distributorName":distributorName,
                  "location":location,
                   "CompanyName":CompanyName,
                   "userName":userName,
                   "password":password
             })
         })
         .then(res => {
             console.log("res aqib", res)
             if (res.status !== 200) {
                 alert("Some thing went wrong...");
             }
             return res.json();
         })
         .then((response) => {
             console.log("pppppp", response);
             if(response.message=="Distribution Created"){
                 window.location = "/"
             }
             else{
                 alert("Something went wrong..")
             }
             setload(false)
         }).catch((error) => {
             console.log(error)
             alert("Please Check Your Internet Connection...")
             setload(false)
         })
        }
     }
    return (
        <>
            <div className="container-fluid ">
                <div className="row">
                    <div className="col-lg-4 col-md-12" />
                    <div className="col-lg-4 col-md-12 mt-4">
                        <div className="wrapper py-4">
                            <div id="formContent" style={{boxShadow:"lightgrey 1px 9px 9px 6px"}}>

                                <div className="py-4 first d-flex justify-content-center">
                                    <h2 className="ml-2 font-weight-bold"> Create an account</h2>
                                </div>
                                    <div className='second'>
                                        <p>
                                        Create an account using the form below.
                                        </p>
                                    </div>
                                <div style={{display:"flex !important",justifyContent:"center !important"}}>
                                    <input type="text" onChange={(e)=>setdistributorName(e.target.value)} id="firstname" className="fadeIn third  mb-3" name="FirstName" placeholder="Distributor Name" />
                                    <input type="text" onChange={(e)=>setlocation(e.target.value)} id="lastname" className="fadeIn fourth  mb-3" name="LastName" placeholder="Location" />
                                    <input type="text" onChange={(e)=>setCompanyName(e.target.value)} id="lastname" className="fadeIn fourth  mb-3" name="LastName" placeholder="Company Name" />
                                    <input type="text" onChange={(e)=>setuserName(e.target.value)} id="email" className="fadeIn fifth  mb-3" name="Email" placeholder="User Name" />
                                    <input type="password" onChange={(e)=>setpassword(e.target.value)} id="password" className="fadeIn sixth mb-3" name="login" placeholder="password" />
                                    <input
                                      onKeyPress={(e) => {
                                        if (e.key === "Enter") {
                                            register();
                                        }
                                      }}
                                    type="password" onChange={(e)=>setconpassword(e.target.value)} id="password" className="fadeIn sixth " name="login" placeholder="Confirm Password" />
                                    <input type="submit" onClick={()=>register()} style={{fontWeight:"bold"}} className="my-4 seventh " defaultValue="Registered Now" />
                                </div>

                                <div id="formFooter" className="py-3">
                                    <p>Already have an Account?<Link className='hovver' to="/">Login Here</Link></p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div className="col-lg-4 col-md-12" />
                </div>
                {load == false ? (
                    <></>
                  ) : (
                    <FullPageLoader />
                  )}
            </div>
        </>
    );
}

export default Registration; 