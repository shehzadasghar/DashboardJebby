
import React from 'react'; 
import "./Createdailysales.css"
import {Link} from "react-router-dom"
import { useState , useRef} from 'react';
import FullPageLoader from "../fullpageloader/fullPageLoader";
import { useEffect } from 'react';
import {connect} from "react-redux"
import {getAllEmployee} from "../../actions/Allemployees"
import {useReactToPrint } from 'react-to-print';
const config = require('../../helpers/config.json');
  
const CreateDailySales = (props) => { 
      const[status,setstatus]=useState("")
      const[statusdate,setstatusdate]=useState("")
      useEffect(()=>{
            var nnn1=new Date().toISOString().substr(0, 10).split("-")[0]
            var nnn2=new Date().toISOString().substr(0, 10).split("-")[1]
            var nnn3=new Date().getDate()-1
            var nnn4=nnn3>9?nnn3:"0"+nnn3
            loadGetEmployees()
            setload(true)
            fetch(`${config['baseUrl']}/dayStatus/get?date=${new Date().toISOString().substr(0, 10)}`, {
                  method: 'GET',
                  headers: { 'Content-Type': 'application/json', "jwt_token": localStorage.getItem("token"), },
              }).then(res => res.json()).then((response) => {
                  setload(false)
                  const allrecovery = response
                  if(response.dayStatus&&response.dayStatus.status!==null&&response.dayStatus.status!==undefined&&response.dayStatus.status!==""){
                        setstatus(response.dayStatus.status)
                        setstatusdate(response.dayStatus.sDate)
                  }
                  else{
                        setload(true)
                        fetch(`${config['baseUrl']}/dayStatus/get?date=${nnn1+"-"+nnn2+"-"+nnn4}`, {
                              method: 'GET',
                              headers: { 'Content-Type': 'application/json', "jwt_token": localStorage.getItem("token"), },
                          }).then(res => res.json()).then((response) => {
                              setload(false)
                              const allrecovery = response
                               setstatus(response.dayStatus.status)
                                    setstatusdate(response.dayStatus.sDate)
                              console.log("status respo", response);
                          }).catch((error) => {
                              console.log("error", error);
                              setload(false)
                              // alert("Please Check Your Internet Connection...")
                          })
                  }
    
                  console.log("status respo", response);
              }).catch((error) => {
                  console.log("error", error);
                  setload(false)
                  // alert("Please Check Your Internet Connection...")
              })
      },[])
      const loadGetEmployees = async () => {
            await props.getAllEmployee()
            return null;
          }
      const [load,setload]=useState(false)
      const [date,setdate]=useState("")
      const [van,setvan]=useState(null)
      const [dsrAmount,setdsrAmount]=useState(null)
      const [cash,setcash]=useState(null)
      const [cheque,setcheque]=useState(null)
      const [credit,setcredit]=useState(null)
      const [bankslip,setbankslip]=useState(null)
      const [dsrNo,setdsrNo]=useState("")
      const [salesmanId,setsalesmanId]=useState(1)
      const [orderBookerId,setorderBookerId]=useState(1)
      const [discountPercentage,setdiscountPercentage]=useState(null)
      const [discountPartyName,setdiscountPartyName]=useState("")
      const [adjustment,setadjustment]=useState(null)
      const[resarray,setresarray]=useState([])
      const CreateSale = async() =>{
            var data={
                  "date":status!==null&&status!==undefined&&status!==""&&status!=="open"&&statusdate<new Date().toISOString().substr(0, 10)?`${new Date().toISOString().substr(0, 10)} ${new Date().getHours()}:${new Date().getMinutes()}:${new Date().getSeconds()}`:status!==null&&status!==undefined&&status!==""&&status!=="open"&&statusdate==new Date().toISOString().substr(0, 10)?`${new Date().getFullYear()}-${new Date().getMonth()+1<10?`0${new Date().getMonth()+1}`:new Date().getMonth()+1}-${new Date().getDate()+1<10?`0${new Date().getDate()+1}`:new Date().getDate()+1} ${new Date().getHours()}:${new Date().getMinutes()}:${new Date().getSeconds()}`:status!==null&&status!==undefined&&status!==""&&status!=="close"&&statusdate<new Date().toISOString().substr(0, 10)?`${new Date().getFullYear()}-${new Date().getMonth()-1<10?`0${new Date().getMonth()-1}`:new Date().getMonth()-1}-${new Date().getDate()-1<10?`0${new Date().getDate()-1}`:new Date().getDate()-1} ${new Date().getHours()}:${new Date().getMinutes()}:${new Date().getSeconds()}`:`${new Date().toISOString().substr(0, 10)} ${new Date().getHours()}:${new Date().getMinutes()}:${new Date().getSeconds()}` ,
                  "distributionId":Number(localStorage.getItem("disid")),
                  "dsrAmount":Number(dsrAmount),
                  "cash":Number(cash),
                  "cheque":Number(cheque),
                  "credit": Number(credit),
                  "salesmanId":Number(salesmanId),
                  "orderBookerId":Number(orderBookerId),
                  "discountPercentage":Number(discountPercentage),
                  "discountPartyName":discountPartyName,
                  "adjustment":Number(adjustment),
                  "dsr":dsrNo,
            }
            console.log("data",data)
            // setload(true)
            // await fetch(`${config['baseUrl']}/sales/create`, {
            //      method: 'POST',
            //      headers: { 'Content-Type': 'application/json','jwt_token':`${localStorage.getItem("token")}` },
            //      body: JSON.stringify({
            //            "date":status!==null&&status!==undefined&&status!==""&&status!=="open"&&statusdate<new Date().toISOString().substr(0, 10)?`${new Date().toISOString().substr(0, 10)} ${new Date().getHours()}:${new Date().getMinutes()}:${new Date().getSeconds()}`:status!==null&&status!==undefined&&status!==""&&status!=="open"&&statusdate==new Date().toISOString().substr(0, 10)?`${new Date().getFullYear()}-${new Date().getMonth()+1<10?`0${new Date().getMonth()+1}`:new Date().getMonth()+1}-${new Date().getDate()+1<10?`0${new Date().getDate()+1}`:new Date().getDate()+1} ${new Date().getHours()}:${new Date().getMinutes()}:${new Date().getSeconds()}`:status!==null&&status!==undefined&&status!==""&&status!=="close"&&statusdate<new Date().toISOString().substr(0, 10)?`${new Date().getFullYear()}-${new Date().getMonth()-1<10?`0${new Date().getMonth()-1}`:new Date().getMonth()-1}-${new Date().getDate()-1<10?`0${new Date().getDate()-1}`:new Date().getDate()-1} ${new Date().getHours()}:${new Date().getMinutes()}:${new Date().getSeconds()}`:`${new Date().toISOString().substr(0, 10)} ${new Date().getHours()}:${new Date().getMinutes()}:${new Date().getSeconds()}` ,
            //            "distributionId":Number(localStorage.getItem("disid")),
            //            "dsrAmount":Number(dsrAmount),
            //            "cash":Number(cash),
            //            "cheque":Number(cheque),
            //            "credit": Number(credit),
            //            "salesmanId":Number(salesmanId),
            //            "orderBookerId":Number(orderBookerId),
            //            "discountPercentage":Number(discountPercentage),
            //            "discountPartyName":discountPartyName,
            //            "adjustment":Number(adjustment),
            //            "dsr":dsrNo,
            //      })
            //  })
            //  .then(res => {
            //      console.log("res aqib", res)
            //      if (res.status !== 200) {
            //          alert("Some thing went wrong...");
            //      }
            //      return res.json();
            //  })
            //  .then((response) => {
            //      console.log("pppppp", response);
            //      var temp=[]
            //      if(Object.entries(response.response).length > 0){
            //             temp.push(response.response)
            //            console.log("fgfghh",temp)
            //            setresarray(temp)
            //      }
            //       // resarray.push(response.response)
            //       // setresarray(resarray)
               
            //      if(response.message=="Sales entry Created"){
            //       //    window.location = "/createdailysales"
            //       alert("Successfully created!")
            //       setsalesmanId(null)
            //       setorderBookerId(null)
            //       setdsrAmount("")
            //       setdsrNo("")
            //       setcash("")
            //       setcheque("")
            //       setcredit("")
            //       setadjustment("")
            //       setdiscountPartyName("")
            //       setdiscountPercentage("")
            //       document.getElementById("inpid").value=""
            //      }
            //      else{
            //          alert("Something went wrong..")
            //      }
            //      setload(false)
            //  }).catch((error) => {
            //      console.log(error)
            //      alert("Please Check Your Internet Connection...")
            //      setload(false)
            //  })
         }
         const componentRef = useRef();
         const handlePrint = useReactToPrint({
           content: () => componentRef.current,
           documentTitle:"All Advance",
           pageStyle:"print",
         });
return ( 
      <>
      <div className="container my-5">
            <div className="row">
                  <div className="col-md-12">
                        <h1>Create Daily Sales</h1>
                  </div>
            </div>
            <div className='bg-white rounded shadow-lg p-5 my-3'>
            <div className="row">
            <div className="col-md-6">
                  <div className="row">
                        <div className="col-md-4 pt-2 pr-lg-0">
                        <label htmlFor=""><strong>Date:</strong></label>
                        </div>
                        <div className="col-md-8 pl-lg-0">
                        <input type="text" readOnly value={status!==null&&status!==undefined&&status!==""&&status!=="open"&&statusdate<new Date().toISOString().substr(0, 10)?new Date().toISOString().substr(0, 10):status!==null&&status!==undefined&&status!==""&&status!=="open"&&statusdate==new Date().toISOString().substr(0, 10)?`${new Date().getFullYear()}-${new Date().getMonth()+1<10?`0${new Date().getMonth()+1}`:new Date().getMonth()+1}-${new Date().getDate()+1<10?`0${new Date().getDate()+1}`:new Date().getDate()+1}`:status!==null&&status!==undefined&&status!==""&&status!=="close"&&statusdate<new Date().toISOString().substr(0, 10)?`${new Date().getFullYear()}-${new Date().getMonth()-1<10?`0${new Date().getMonth()-1}`:new Date().getMonth()-1}-${new Date().getDate()-1<10?`0${new Date().getDate()-1}`:new Date().getDate()-1}`:new Date().toISOString().substr(0, 10)} className='form-control w-100' placeholder='Date' />
                        </div>
                  </div>
                        
                        
                  </div>
                  <div className="col-md-6">
                  <div className="row">
                        <div className="col-md-4 pr-lg-0 pt-2">
                        <label htmlFor=""><strong>Sales Man Name:</strong></label>
                        </div>
                        <div className="col-md-8 pl-lg-0">
                        <select className='form-control w-100' onChange={(e)=>setsalesmanId(e.target.value)}>
                 <option value="">--Select--</option>
                {
                props.allemployeeReducer&&props.allemployeeReducer.allemployee&&props.allemployeeReducer.allemployee.length>0?props.allemployeeReducer.allemployee.map(val=>(
                  
                        val.Roles&&val.Roles.length>0?val.Roles.filter(data=>data.roleName=="salesman").map(role=>(
                              <option value={role.EmployeeRole.empId}>{val.employeeName}</option>
                        )):""
                 )):""}
                 </select>
                        </div>
                  </div>
                  
               
                  </div>
                 
            </div>
            <div className="row mt-4">
            <div className="col-md-6">
            <div className="row">
                        <div className="col-md-4 pr-lg-0 pt-2">
                        <label htmlFor=""><strong>Order Booker Name:</strong></label>
                        </div>
                        <div className="col-md-8 pl-lg-0">
                        <select className='form-control w-100' onChange={(e)=>setorderBookerId(e.target.value)}>
                        <option value="">--Select--</option>
                {
                props.allemployeeReducer&&props.allemployeeReducer.allemployee&&props.allemployeeReducer.allemployee.length>0?props.allemployeeReducer.allemployee.map(val=>(
                  
                        val.Roles&&val.Roles.length>0?val.Roles.filter(data=>data.roleName=="orderbooker").map(role=>(
                              <option value={role.EmployeeRole.empId}>{val.employeeName}</option>
                        )):""
                 )):""}
                 </select>
                        </div>
                  </div>
                 
                  
                  </div>
            <div className="col-md-6">
            <div className="row">
                        <div className="col-md-4 pr-lg-0 pt-2">
                        <label htmlFor=""><strong>DSR No</strong></label>
                        </div>
                        <div className="col-md-8 pl-lg-0">
                        <input value={dsrNo} type="text" onChange={(e)=>setdsrNo(e.target.value)} className='form-control w-100' placeholder='DSR No' />
                        </div>
                  </div>
                        
                       
                  </div>
                
            </div>
            <div className="row mt-4">
            <div className="col-md-6">
            <div className="row">
                        <div className="col-md-4 pr-lg-0 pt-2">
                        <label htmlFor=""><strong>DSR Amount</strong></label>
                        </div>
                        <div className="col-md-8 pl-lg-0">
                        <input value={dsrAmount} type="number" onChange={(e)=>setdsrAmount(e.target.value)} className='form-control w-100' placeholder='DSR Amount' />
                        </div>
                  </div>
                  
                  
                  </div>
            <div className="col-md-6">
            <div className="row">
                        <div className="col-md-4 pr-lg-0 pt-2">
                        <label htmlFor=""><strong>Cash</strong></label>
                        </div>
                        <div className="col-md-8 pl-lg-0">
                        <input value={cash} type="number" onChange={(e)=>setcash(e.target.value)} className='form-control w-100' placeholder='Cash' />
                        </div>
                  </div>
                        
                     
                  </div>
                  
            </div>
            <div className="row mt-4 mb-5">
            <div className="col-md-6">
            <div className="row">
                        <div className="col-md-4 pr-lg-0 pt-2">
                        <label htmlFor=""><strong>Cheque</strong></label>
                        </div>
                        <div className="col-md-8 pl-lg-0">
                        <input value={cheque} type="number" onChange={(e)=>setcheque(e.target.value)} className='form-control w-100' placeholder='Cheque' />
                        </div>
                  </div>
                       
                      
                  </div>
                  {/* <div className="col-md-6">
                  <label htmlFor=""><strong>Bank Slip</strong></label>
                  <input type="text" onChange={(e)=>setbankslip(e.target.value)} className='form-control w-100' placeholder='Bank Slip' />
                  </div> */}
                  <div className="col-md-6">
                  <div className="row">
                        <div className="col-md-4 pr-lg-0 pt-2">
                        <label htmlFor=""><strong>Credit</strong></label>
                        </div>
                        <div className="col-md-8 pl-lg-0">
                        <input value={credit} type="number" onChange={(e)=>setcredit(e.target.value)} className='form-control w-100' placeholder='Credit' />
                        </div>
                  </div>
               
                
                  </div>
            </div>
            <hr />
            <div className="row mt-5">
            {/* <div className="col-md-6">
                        <label htmlFor=""><strong>VAN</strong></label>
                        <input type="number" onChange={(e)=>setvan(e.target.value)} className='form-control w-100' placeholder='VAN' />
                  </div> */}
                         <div className="col-md-6">
                         <div className="row">
                        <div className="col-md-4 pr-lg-0 pt-2">
                        <label htmlFor=""><strong>% Party Name</strong></label>
                        </div>
                        <div className="col-md-8 pl-lg-0">
                        <input value={discountPartyName} type="text" onChange={(e)=>setdiscountPartyName(e.target.value)} className='form-control w-100' placeholder='4% Party Name' />
                        </div>
                  </div>
                       
                       
                  </div>
                  <div className="col-md-6">
                  <div className="row">
                        <div className="col-md-4 pr-lg-0 pt-2">
                        <label htmlFor=""><strong>Amount</strong></label>
                        </div>
                        <div className="col-md-8 pl-lg-0">
                        <input value={adjustment} type="number" onChange={(e)=>setadjustment(e.target.value)} className='form-control w-100' placeholder='Amount' />
                        </div>
                  </div>
                  
               
                  </div>
            </div>
            <div className="row mt-4">
     
                  <div className="col-md-6">
                  <div className="row">
                        <div className="col-md-4 pr-lg-0 pt-2">
                        <label htmlFor=""><strong>%</strong></label>
                        </div>
                        <div className="col-md-8 pl-lg-0">
                                        <input
                                        onKeyPress={(e) => {
                                           if (e.key === "Enter") {
                                                CreateSale();
                                           }
                                         }}
                                     value={discountPercentage} type="number" onChange={(e)=>setdiscountPercentage(e.target.value)} className='form-control w-100' placeholder='4%' />
                       
                        </div>
                  </div>
                  
                
                  </div>
                  <div className="col-md-6">
                  <div className="row">
                        <div className="col-md-4 pr-lg-0 pt-2">
                        <label htmlFor=""><strong>Total</strong></label>
                        </div>
                        <div className="col-md-8 pl-lg-0">
                        <input type="number"
                            onKeyPress={(e) => {
                              if (e.key === "Enter") {
                                    CreateSale();
                              }
                            }}
                        id='inpid' readOnly value={adjustment/100*(100-discountPercentage)} className='form-control w-100' placeholder='Total' />
                        
                        </div>
                  </div>
                  
                 
                  </div>
            </div>
            <div className="row mt-5">
                  <div className="col-md-12 text-center">
                        <Link onClick={()=>CreateSale()}><button className='border-0 rounded py-2 px-5  btnorderbookersub' ><strong>Submit</strong></button></Link>
                
                  </div>
            </div>


            {
                  resarray&&resarray.length>0?resarray.map(res=>(
                        <>
                        <button className='btn btn-primary rounded mb-3 mt-4' onClick={handlePrint}>Print this out!</button>
                  <div ref={componentRef} style={{overflow:"auto",maxHeight:"500px"}} className="">
                  <table className='table border-0  w-100' >
                  <tr className='border-0 table-secondary'>
                         <th style={{border:"1px solid black"}}>Date</th>
                         {/* <th style={{border:"1px solid black"}}>Van</th> */}
                         <th style={{border:"1px solid black"}}>DSR No</th>
                         <th style={{border:"1px solid black"}}>DSR Amount</th>
                         <th style={{border:"1px solid black"}}>Cash</th>
                         <th style={{border:"1px solid black"}}>Cheque</th>
                         <th style={{border:"1px solid black"}}>Credit</th>
                         {/* <th style={{border:"1px solid black"}}>Bank Slip</th> */}
                         <th style={{border:"1px solid black"}}>Adjustment</th>
                         <th style={{border:"1px solid black"}}>Percentage Discount</th>
                         <th style={{border:"1px solid black"}}>Party Name</th>
                         <th style={{border:"1px solid black"}}>Shortage</th>
                         {/* <th style={{border:"1px solid black"}}>Remarks</th> */}
                         <th style={{border:"1px solid black"}}>Orderbooker</th>
                         <th style={{border:"1px solid black"}}>Salesman</th>
                     </tr>
                          <tr>
                          <td style={{border:"1px solid black"}}>{`${res.createdAt.split("T")[0]} ${Number(res.createdAt.split("T")[1].split(".")[0].split(":")[0])+5}:${res.createdAt.split("T")[1].split(".")[0].split(":")[1]}:${res.createdAt.split("T")[1].split(".")[0].split(":")[2]}`}</td>
                          {/* <td style={{border:"1px solid black"}}>{res.van}</td> */}
                          <td style={{border:"1px solid black"}}>{res.dsrNo}</td>
                          <td style={{border:"1px solid black"}}>{res.dsrAmount}</td>
                          <td style={{border:"1px solid black"}}>{res.cash}</td>
                          <td style={{border:"1px solid black"}}>{res.cheque}</td>
                          <td style={{border:"1px solid black"}}>{res.credit}</td>
                          {/* <td style={{border:"1px solid black"}}>{res.bankSlip}</td> */}
                          <td style={{border:"1px solid black"}}>{res.adjustment}</td>
                          <td style={{border:"1px solid black"}}>{res.percentageDiscount}</td>
                          <td style={{border:"1px solid black"}}>{res.percentageDiscountPartyName}</td>
                          <td style={{border:"1px solid black"}}>{res.shortage}</td>
                          {/* <td style={{border:"1px solid black"}}>{res.remarks}</td> */}
                          <td style={{border:"1px solid black"}}>{props.allemployeeReducer&&props.allemployeeReducer.allemployee&&props.allemployeeReducer.allemployee.length>0?props.allemployeeReducer.allemployee.filter(data=>data.id==res.salesmanId)[0].employeeName:""}</td>
                          <td style={{border:"1px solid black"}}>{props.allemployeeReducer&&props.allemployeeReducer.allemployee&&props.allemployeeReducer.allemployee.length>0?props.allemployeeReducer.allemployee.filter(data=>data.id==res.orderbookerId)[0].employeeName:""}</td>
                      </tr>
                      <>
                          <tr>
                          <td style={{border:"1px solid black"}} colSpan="5"><b>Cash in Hand</b></td>
                          <td style={{border:"1px solid black"}}>{res.cash}</td>
                          <td style={{border:"1px solid black"}} colSpan="5"><b>Total Shortage/Access</b></td>
                          <td style={{border:"1px solid black"}}>{res.shortage}</td>
                      </tr>
                         <tr>
                         <td style={{border:"1px solid black"}} colSpan="11"><b>Amount After Shortage</b></td>
                         <td style={{border:"1px solid black"}}>{res.amountAfterShortage}</td>
                        
                     </tr>
                      </>
      </table>
      </div></>)):
      ""
            }
            </div>
            {props.allemployeeReducer.loading == true ? (
                    <></>
                  ) : (
                    <FullPageLoader />
                  )}
            {load == false ? (
                    <></>
                  ) : (
                    <FullPageLoader />
                  )}
      </div>
      </>
); 
} 
const mapStateToProps = (state) => ({
      allemployeeReducer: state.allemployeeReducer,
    });
    
    const mapDispatchToProps = (dispatch) => ({
      getAllEmployee: () => dispatch(getAllEmployee()),
    });
    export default connect(
      mapStateToProps,
      mapDispatchToProps
    )(CreateDailySales);