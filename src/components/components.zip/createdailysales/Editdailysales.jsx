
import React from 'react'; 
import "./Createdailysales.css"
import {Link,useLocation} from "react-router-dom"
import { useState } from 'react';
import FullPageLoader from "../fullpageloader/fullPageLoader";
import { useEffect } from 'react';
import {connect} from "react-redux"
import {getAllEmployee} from "../../actions/Allemployees"
import {getAllDailySalesReport ,getAllDailySalesEdit,getAllDailySalesReportEdit} from "../../actions/Alldailysales"
const config = require('../../helpers/config.json');
  
const EditDailySales = (props) => { 
    const search = useLocation().search;
    const idd = new URLSearchParams(search).get("id");
    const datees = new URLSearchParams(search).get("date");
    var dateess1=datees.split("-")[0]
    var dateess2=datees.split("-")[1]
    var dateess3=datees.split("-")[2]-1
    var condate=dateess1+"-"+dateess2+"-"+dateess3
      useEffect(async()=>{
            console.log("dfgh",condate)
            loadGetEmployees()
            await props.getAllDailySalesEdit(datees)
            await props.getAllDailySalesReportEdit(datees)
      },[])
      const loadGetEmployees = async () => {
            await props.getAllEmployee()
            return null;
          }
      const [load,setload]=useState(false)
      const [date,setdate]=useState("")
      const [van,setvan]=useState(null)
      const [dsrAmount,setdsrAmount]=useState(null)
      const [cash,setcash]=useState(null)
      const [cheque,setcheque]=useState(null)
      const [credit,setcredit]=useState(null)
      const [bankslip,setbankslip]=useState(null)
      const [dsrNo,setdsrNo]=useState("")
      const [salesmanId,setsalesmanId]=useState(null)
      const [orderBookerId,setorderBookerId]=useState(null)
      const [discountPercentage,setdiscountPercentage]=useState(null)
      const [discountPartyName,setdiscountPartyName]=useState("")
      const [adjustment,setadjustment]=useState(null)
      const CreateSale = async() =>{
            setload(true)
            await fetch(`${config['baseUrl']}/sales/update`, {
                 method: 'PUT',
                 headers: { 'Content-Type': 'application/json','jwt_token': localStorage.getItem("token") },
                 body: JSON.stringify({
                  "date":datees,
                  "salesId":Number(idd),
                  "dsrAmount":dsrAmount!==""&&dsrAmount!==null&&dsrAmount!==undefined?Number(dsrAmount):props.alldailysalesReducer.alldailysales.sales&&props.alldailysalesReducer.alldailysales.sales.length>0?Number(props.alldailysalesReducer.alldailysales.sales.filter(data=>data.id==idd)[0].dsrAmount):null,
                  "cash":cash!==""&&cash!==null&&cash!==undefined?Number(cash):props.alldailysalesReducer.alldailysales.sales&&props.alldailysalesReducer.alldailysales.sales.length>0?Number(props.alldailysalesReducer.alldailysales.sales.filter(data=>data.id==idd)[0].cash):null,
                  "cheque":cheque!==""&&cheque!==null&&cheque!==undefined?Number(cheque):props.alldailysalesReducer.alldailysales.sales&&props.alldailysalesReducer.alldailysales.sales.length>0?Number(props.alldailysalesReducer.alldailysales.sales.filter(data=>data.id==idd)[0].cheque):null,
                  "credit": credit!==""&&credit!==null&&credit!==undefined?Number(credit):props.alldailysalesReducer.alldailysales.sales&&props.alldailysalesReducer.alldailysales.sales.length>0?Number(props.alldailysalesReducer.alldailysales.sales.filter(data=>data.id==idd)[0].credit):null,
                  "salesmanId":salesmanId!==""&&salesmanId!==null&&salesmanId!==undefined?Number(salesmanId):props.alldailysalesReducer.alldailysales.sales&&props.alldailysalesReducer.alldailysales.sales.length>0?Number(props.alldailysalesReducer.alldailysales.sales.filter(data=>data.id==idd)[0].salesman.id):null,
                  "orderBookerId":orderBookerId!==""&&orderBookerId!==null&&orderBookerId!==undefined?Number(orderBookerId):props.alldailysalesReducer.alldailysales.sales&&props.alldailysalesReducer.alldailysales.sales.length>0?Number(props.alldailysalesReducer.alldailysales.sales.filter(data=>data.id==idd)[0].orderbooker.id):null,
                  "discountPercentage":discountPercentage!==""&&discountPercentage!==null&&discountPercentage!==undefined?Number(discountPercentage):props.alldailysalesReducer.alldailysales.sales&&props.alldailysalesReducer.alldailysales.sales.length>0?Number(props.alldailysalesReducer.alldailysales.sales.filter(data=>data.id==idd)[0].percentageDiscount):null,
                  "discountPartyName":discountPartyName!==""&&discountPartyName!==null&&discountPartyName!==undefined?discountPartyName:props.alldailysalesReducer.alldailysales.sales&&props.alldailysalesReducer.alldailysales.sales.length>0?props.alldailysalesReducer.alldailysales.sales.filter(data=>data.id==idd)[0].percentageDiscountPartyName:null,
                  "adjustment":adjustment!==""&&adjustment!==null&&adjustment!==undefined?Number(adjustment):props.alldailysalesReducer.alldailysales.sales&&props.alldailysalesReducer.alldailysales.sales.length>0?Number(props.alldailysalesReducer.alldailysales.sales.filter(data=>data.id==idd)[0].adjustment):null,
                  "salesStatus":null,
                  "dsr":dsrNo!==""&&dsrNo!==null&&dsrNo!==undefined?dsrNo:props.alldailysalesReducer.alldailysales.sales&&props.alldailysalesReducer.alldailysales.sales.length>0?props.alldailysalesReducer.alldailysales.sales.filter(data=>data.id==idd)[0].dsrNo:null,
            })
             })
             .then(res => {
                 console.log("res aqib", res)
                 if (res.status !== 200) {
                     alert("Some thing went wrong...");
                 }
                 return res.json();
             })
             .then((response) => {
                 console.log("pppppp", response);
                 if(response.message=="Sales entry Updated"){
                     window.location = "/alldailysales"
                 }
                 else{
                     alert("Something went wrong..")
                 }
                 setload(false)
             }).catch((error) => {
                 console.log(error)
                 alert("Please Check Your Internet Connection...")
                 setload(false)
             })
         }
 
return ( 
      <>
      <div className="container my-5">
            <div className="row">
                  <div className="col-md-12">
                        <h1>Edit Daily Sales</h1>
                  </div>
            </div>
            {
                props.alldailysalesReducer.alldailysales.sales&&props.alldailysalesReducer.alldailysales.sales.length>0?props.alldailysalesReducer.alldailysales.sales.filter(data=>data.id==idd).map(val=>(
<div className='bg-white rounded shadow-lg p-5 my-3'>
            <div className="row">
            <div className="col-md-6">
                  <div className="row">
                        <div className="col-md-4 pt-2 pr-lg-0">
                        <label htmlFor=""><strong>Date:</strong></label>
                        </div>
                        <div className="col-md-8 pl-lg-0">
                        <input type="date" readOnly value={val.salesDate.split("T")[0]} className='form-control w-100' placeholder='Date' />
                        </div>
                  </div>
                        
                        
                  </div>
                  <div className="col-md-6">
                  <div className="row">
                        <div className="col-md-4 pr-lg-0 pt-2">
                        <label htmlFor=""><strong>Sales Man Name:</strong></label>
                        </div>
                        <div className="col-md-8 pl-lg-0">
                        <select className='form-control w-100' onChange={(e)=>setsalesmanId(e.target.value)}>
                            
                 <option value={val.salesman.id}>{val.salesman.employeeName}</option>
                {
                props.allemployeeReducer&&props.allemployeeReducer.allemployee&&props.allemployeeReducer.allemployee.length>0?props.allemployeeReducer.allemployee.map(val=>(
                  
                        val.Roles&&val.Roles.length>0?val.Roles.filter(data=>data.roleName=="salesman").map(role=>(
                              <option value={role.EmployeeRole.empId}>{val.employeeName}</option>
                        )):""
                 )):""}
                 </select>
                        </div>
                  </div>
                  
               
                  </div>
                 
            </div>
            <div className="row mt-4">
            <div className="col-md-6">
            <div className="row">
                        <div className="col-md-4 pr-lg-0 pt-2">
                        <label htmlFor=""><strong>Order Booker Name:</strong></label>
                        </div>
                        <div className="col-md-8 pl-lg-0">
                        <select className='form-control w-100' onChange={(e)=>setorderBookerId(e.target.value)}>
                        <option value={val.orderbooker.id}>{val.orderbooker.employeeName}</option>
                {
                props.allemployeeReducer&&props.allemployeeReducer.allemployee&&props.allemployeeReducer.allemployee.length>0?props.allemployeeReducer.allemployee.map(val=>(
                  
                        val.Roles&&val.Roles.length>0?val.Roles.filter(data=>data.roleName=="orderbooker").map(role=>(
                              <option value={role.EmployeeRole.empId}>{val.employeeName}</option>
                        )):""
                 )):""}
                 </select>
                        </div>
                  </div>
                 
                  
                  </div>
            <div className="col-md-6">
            <div className="row">
                        <div className="col-md-4 pr-lg-0 pt-2">
                        <label htmlFor=""><strong>DSR No</strong></label>
                        </div>
                        <div className="col-md-8 pl-lg-0">
                        <input type="text" defaultValue={val.dsrNo} onChange={(e)=>setdsrNo(e.target.value)} className='form-control w-100' placeholder='DSR No' />
                        </div>
                  </div>
                        
                       
                  </div>
                
            </div>
            <div className="row mt-4">
            <div className="col-md-6">
            <div className="row">
                        <div className="col-md-4 pr-lg-0 pt-2">
                        <label htmlFor=""><strong>DSR Amount</strong></label>
                        </div>
                        <div className="col-md-8 pl-lg-0">
                        <input type="number" defaultValue={val.dsrAmount} onChange={(e)=>setdsrAmount(e.target.value)} className='form-control w-100' placeholder='DSR Amount' />
                        </div>
                  </div>
                  
                  
                  </div>
            <div className="col-md-6">
            <div className="row">
                        <div className="col-md-4 pr-lg-0 pt-2">
                        <label htmlFor=""><strong>Cash</strong></label>
                        </div>
                        <div className="col-md-8 pl-lg-0">
                        <input type="number" defaultValue={val.cash} onChange={(e)=>setcash(e.target.value)} className='form-control w-100' placeholder='Cash' />
                        </div>
                  </div>
                        
                     
                  </div>
                  
            </div>
            <div className="row mt-4 mb-5">
            <div className="col-md-6">
            <div className="row">
                        <div className="col-md-4 pr-lg-0 pt-2">
                        <label htmlFor=""><strong>Cheque</strong></label>
                        </div>
                        <div className="col-md-8 pl-lg-0">
                        <input type="number" defaultValue={val.cheque} onChange={(e)=>setcheque(e.target.value)} className='form-control w-100' placeholder='Cheque' />
                        </div>
                  </div>
                       
                      
                  </div>
                  {/* <div className="col-md-6">
                  <label htmlFor=""><strong>Bank Slip</strong></label>
                  <input type="text" onChange={(e)=>setbankslip(e.target.value)} className='form-control w-100' placeholder='Bank Slip' />
                  </div> */}
                  <div className="col-md-6">
                  <div className="row">
                        <div className="col-md-4 pr-lg-0 pt-2">
                        <label htmlFor=""><strong>Credit</strong></label>
                        </div>
                        <div className="col-md-8 pl-lg-0">
                        <input type="number" defaultValue={val.credit} onChange={(e)=>setcredit(e.target.value)} className='form-control w-100' placeholder='Credit' />
                        </div>
                  </div>
               
                
                  </div>
            </div>
            <hr />
            <div className="row mt-5">
            {/* <div className="col-md-6">
                        <label htmlFor=""><strong>VAN</strong></label>
                        <input type="number" onChange={(e)=>setvan(e.target.value)} className='form-control w-100' placeholder='VAN' />
                  </div> */}
                         <div className="col-md-6">
                         <div className="row">
                        <div className="col-md-4 pr-lg-0 pt-2">
                        <label htmlFor=""><strong>% Party Name</strong></label>
                        </div>
                        <div className="col-md-8 pl-lg-0">
                        <input type="text" defaultValue={val.percentageDiscountPartyName} onChange={(e)=>setdiscountPartyName(e.target.value)} className='form-control w-100' placeholder='4% Party Name' />
                        </div>
                  </div>
                       
                       
                  </div>
                  <div className="col-md-6">
                  <div className="row">
                        <div className="col-md-4 pr-lg-0 pt-2">
                        <label htmlFor=""><strong>Amount</strong></label>
                        </div>
                        <div className="col-md-8 pl-lg-0">
                        <input type="number" defaultValue={val.adjustment} onChange={(e)=>setadjustment(e.target.value)} className='form-control w-100' placeholder='Amount' />
                        </div>
                  </div>
                  
               
                  </div>
            </div>
            <div className="row mt-4">
     
                  <div className="col-md-6">
                  <div className="row">
                        <div className="col-md-4 pr-lg-0 pt-2">
                        <label htmlFor=""><strong>%</strong></label>
                        </div>
                        <div className="col-md-8 pl-lg-0">
                        <input type="number" defaultValue={val.percentageDiscount} onChange={(e)=>setdiscountPercentage(e.target.value)} className='form-control w-100' placeholder='4%' />
                        </div>
                  </div>
                  
                
                  </div>
                  <div className="col-md-6">
                  <div className="row">
                        <div className="col-md-4 pr-lg-0 pt-2">
                        <label htmlFor=""><strong>Total</strong></label>
                        </div>
                        <div className="col-md-8 pl-lg-0">
                        <input type="number"  readOnly value={val.adjustment/100*(100-val.percentageDiscount)} className='form-control w-100' placeholder='Total' />
                        </div>
                  </div>
                  
                 
                  </div>
            </div>
            <div className="row mt-5">
                  <div className="col-md-12 text-center">
                 <Link onClick={()=>CreateSale()}><button className='border-0 rounded py-2 px-5  btnorderbookersub' ><strong>Submit</strong></button></Link>
                  </div>
            </div>
            </div>
                )):""
            }
            
            {props.allemployeeReducer.loading == true ? (
                    <></>
                  ) : (
                    <FullPageLoader />
                  )}
            {load == false ? (
                    <></>
                  ) : (
                    <FullPageLoader />
                  )}
      </div>
      </>
); 
} 
const mapStateToProps = (state) => ({
      allemployeeReducer: state.allemployeeReducer,
      alldailysalesReducer: state.alldailysalesReducer,
    });
    
    const mapDispatchToProps = (dispatch) => ({
      getAllEmployee: () => dispatch(getAllEmployee()),
      // getAllDailySales: (date2,empid,todate) => dispatch(getAllDailySales(date2,empid,todate)),
      getAllDailySalesEdit: (date2) => dispatch(getAllDailySalesEdit(date2)),
      getAllDailySalesReport: (date2,empid,todate) => dispatch(getAllDailySalesReport(date2,empid,todate)),
      getAllDailySalesReportEdit: (date2) => dispatch(getAllDailySalesReportEdit(date2)),
    });
    export default connect(
      mapStateToProps,
      mapDispatchToProps
    )(EditDailySales);