
import React , {useState} from 'react'; 
import "./Createdistribution.css"
import {Link} from "react-router-dom"
import { connect } from "react-redux";
import { DistributionCreate } from "../../actions/Distributioncreateaction";
import { useEffect } from 'react';
  
const CreateDistribution = (props) => { 
    useEffect(()=>{

    },[])
const [distributorName,setdistributorName]=useState("")
const [location,setlocation]=useState("")
const [CompanyName,setCompanyName]=useState("")

const craeteDistribution=async()=>{
   await props.DistributionCreate(distributorName,location,CompanyName)
}
 
return ( 
      <>
      <div className="container my-5">
            <div className="row">
                  <div className="col-md-12">
                        <h1>Create Distribution</h1>
                  </div>
            </div>
            <div className='bg-white rounded shadow-lg p-5 my-3'>
            <div className="row">
                  <div className="col-md-6">
                        <label htmlFor=""><strong>Distribution Name</strong></label>
                        <input type="text"
                        onChange={(e)=>setdistributorName(e.target.value)}
                        className='form-control w-100' placeholder='Distribution Name' />
                  </div>
                  <div className="col-md-6">
                  <label htmlFor=""><strong>Location</strong></label>
                  <input type="text"
                  onChange={(e)=>setlocation(e.target.value)}
                  className='form-control w-100' placeholder='Location' />
                  </div>
            </div>
            <div className="row mt-4">
                  <div className="col-md-6">
                  <label htmlFor=""><strong>Company Name</strong></label>
                        <input type="text" 
                        onChange={(e)=>setCompanyName(e.target.value)}
                        className='form-control w-100' placeholder='Company Name' />
                  </div>
            </div>
            <div className="row mt-5">
                  <div className="col-md-12 text-center">
                 <Link onClick={()=>craeteDistribution()}><button className='border-0 rounded py-2 px-5  btnorderbookersub' ><strong>Submit</strong></button></Link>
                  </div>
            </div>
            </div>
      </div>
      </>
); 
} 
  
const mapStateToProps = (state) => ({
    DistributionCreateReducer:state.DistributionCreateReducer,
  });
  
  const mapDispatchToProps = (dispatch) => ({
    DistributionCreate: (distributorName, location,CompanyName) =>
    dispatch(DistributionCreate(distributorName, location,CompanyName)),
  });
  export default connect(mapStateToProps, mapDispatchToProps)(CreateDistribution);