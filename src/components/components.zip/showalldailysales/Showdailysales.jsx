import React , {useState,useEffect,useRef} from 'react'; 
import "./Showalldailysales.css"
import {Link} from "react-router-dom"
import Modal from "react-modal";
import {getAllEmployee} from "../../actions/Allemployees"
import {getAllDailySalesReport} from "../../actions/Alldailysales"
import {connect} from "react-redux"
import FullPageLoader from "../fullpageloader/fullPageLoader";
import { DateRangePicker } from 'rsuite';
import 'rsuite/dist/rsuite.min.css'
import {useReactToPrint } from 'react-to-print';
const config = require('../../helpers/config.json');
  
const ShowDailySales = (props) => { 
  const componentRef = useRef();
  const handlePrint = useReactToPrint({
    content: () => componentRef.current,
    documentTitle:"All Advance",
    pageStyle:"print",
  });
  var date2 = new Date
  const [AdvancemodalIsOpen, setAdvanceModalIsOpen] = useState(false);
  const[dateFrom,setdateFrom]=useState(null)
  const[dateTo,setdateTo]=useState(null)
  const[empId,setempId]=useState(null)
  const[dat,setdat]=useState([date2,date2])
  const [load,setload]=useState(false)
  const[status,setstatus]=useState("")
  const[oversales,setoversales]=useState([])
  const[totsales,settotsales]=useState([])
  const[ddd,setddd]=useState("")
  useEffect(async() => {
    loadGetEmployees()
    // await props.getAllDailySales()
    await props.getAllDailySalesReport()
    setload(true)
    var okdateto;
    var okdatefrom;
    okdatefrom=dat[0].toISOString().substr(0, 10)
    okdateto=dat[1].toISOString().substr(0, 10) 

    var nnn1=new Date().toISOString().substr(0, 10).split("-")[0]
    var nnn2=new Date().toISOString().substr(0, 10).split("-")[1]
    var nnn3=new Date().getDate()-1
    console.log("fgnn",nnn1+nnn2+nnn3)
    fetch(`${config['baseUrl']}/sales/getSales?from=${new Date().toISOString().substr(0, 10)}`, {
      method: 'GET',
      headers: { 'Content-Type': 'application/json', "jwt_token": localStorage.getItem("token"), },
  }).then(res => res.json()).then((response) => {
    setload(false)
      const alldailysales = response
      var temparr=[]
      temparr=[...response.sales]
      setoversales(temparr)
      var temparr1=[]
      temparr1=[...response.totalSales]
      settotsales(temparr1)
      console.log("dsales", response);
  }).catch((error) => {
    setload(false)
      console.log("error", error);
  })

    fetch(`${config['baseUrl']}/dayStatus/get?date=${new Date().toISOString().substr(0, 10)}`, {
      method: 'GET',
      headers: { 'Content-Type': 'application/json', "jwt_token": localStorage.getItem("token"), },
  }).then(res => res.json()).then((response) => {
      setload(false)
      const allrecovery = response
setstatus(response.dayStatus.status)
setddd(response.dayStatus.sDate)
      console.log("status", response);
  }).catch((error) => {
      console.log("error", error);
      setload(false)
      // alert("Please Check Your Internet Connection...")
  })  

  fetch(`${config['baseUrl']}/report?from=${new Date().toISOString().substr(0, 10)}`, {
    method: 'GET',
    headers: { 'Content-Type': 'application/json', "jwt_token": localStorage.getItem("token"), },
}).then(res => res.json()).then((response) => {
    const alldailysalesreport = response
settotexp(response.totalExpenses.total_expenses)
settotadv(response.totalAdvance.total_advance)
settotchkb(response.totalBounceChequeAmount.total_bounce_cheque_amount)
settotrec(response.totalRecovery.total_recovery)
    console.log("dsalsesreport", response);
}).catch((error) => {
    console.log("error", error);
})
    },[]);
    const loadGetEmployees = async () => {
      await props.getAllEmployee()
      return null;
    }
    const getAllSales = async(datee,empIdd) =>{
      
      var okdateto;
      var okdatefrom;
      console.log("empid",empIdd,datee)
      var url = `${config['baseUrl']}/sales/getSales?`
      var url1 = `${config['baseUrl']}/dayStatus/get?`
      var url2 = `${config['baseUrl']}/report?`
     if(empIdd !== null && empIdd !== undefined){
      console.log("emp is not null",empIdd  );
      okdatefrom=datee[0].toISOString().substr(0, 10)
      okdateto=datee[1].toISOString().substr(0, 10) 
       url = url + `employeeId=${empIdd}&`
       url2 = url2 + `employeeId=${empIdd}&`
       url1=url1 + `date=${okdateto}`
     }
     if(datee !==null && datee !==undefined && datee.length >0){
      okdatefrom=datee[0].toISOString().substr(0, 10)
      okdateto=datee[1].toISOString().substr(0, 10)  
      console.log("okdates",okdatefrom,okdateto) 
       url = url + `from=${okdatefrom}&to=${okdateto}`
       url2 = url2 + `from=${okdatefrom}&to=${okdateto}`
       url1=url1 + `date=${okdateto}`
    }
     
     console.log("hjhj",url)


setload(true)

      fetch(url, {
        method: 'GET',
        headers: { 'Content-Type': 'application/json', "jwt_token": localStorage.getItem("token"), },
    }).then(res => res.json()).then((response) => {
      setload(false)
        const alldailysales = response
        var temparr=[]
        temparr=[...response.sales]
        setoversales(temparr)
        var temparr1=[]
        temparr1=[...response.totalSales]
        settotsales(temparr1)
        console.log("dsales", response);
    }).catch((error) => {
      setload(false)
        console.log("error", error);
    })

      fetch(url1, {
        method: 'GET',
        headers: { 'Content-Type': 'application/json', "jwt_token": localStorage.getItem("token"), },
    }).then(res => res.json()).then((response) => {
        setload(false)
        const allrecovery = response
setstatus(response.dayStatus.status)
setddd(response.dayStatus.sDate)
        console.log("status", response);
    }).catch((error) => {
        console.log("error", error);
        setload(false)
        // alert("Please Check Your Internet Connection...")
    })  


    fetch(url2, {
      method: 'GET',
      headers: { 'Content-Type': 'application/json', "jwt_token": localStorage.getItem("token"), },
  }).then(res => res.json()).then((response) => {
      const alldailysalesreport = response
settotexp(response.totalExpenses.total_expenses)
settotadv(response.totalAdvance.total_advance)
settotchkb(response.totalBounceChequeAmount.total_bounce_cheque_amount)
settotrec(response.totalRecovery.total_recovery)
      console.log("dsalsesreport", response);
  }).catch((error) => {
      console.log("error", error);
  })
    }

const[totexp,settotexp]=useState("")
const[totadv,settotadv]=useState("")
const[totchkb,settotchkb]=useState("")
const[totrec,settotrec]=useState("")


      const closedstatus = async(id,status) =>{
       if(status=="open"){
        setload(true)
        await fetch(`${config['baseUrl']}/sales/update`, {
             method: 'PUT',
             headers: { 'Content-Type': 'application/json','jwt_token': localStorage.getItem("token") },
             body: JSON.stringify({
              "date":null,
              "salesId":Number(id),
              "dsrAmount":null,
              "cash":null,
              "cheque":null,
              "credit":null,
              "salesmanId":null,
              "orderBookerId":null,
              "discountPercentage":null,
              "discountPartyName":null,
              "adjustment":null,
              "salesStatus":"close",
        })
         })
         .then(res => {
             console.log("res aqib", res)
             if (res.status !== 200) {
                 alert("Some thing went wrong...");
             }
             return res.json();
         })
         .then((response) => {
             console.log("pppppp", response);
             if(response.message=="Sales entry Updated"){
                 window.location = "/alldailysales"
             }
             else{
                 alert("Something went wrong..")
             }
             setload(false)
         }).catch((error) => {
             console.log(error)
             alert("Please Check Your Internet Connection...")
             setload(false)
         })
       }
     }
     const daystatus = async() =>{
       setload(true)
       await fetch(`${config['baseUrl']}/dayStatus/update`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json','jwt_token': localStorage.getItem("token") },
            body: JSON.stringify({
              "status":"close",
              "date":`${new Date().toISOString().substr(0, 10)}`
       })
        })
        .then(res => {
            console.log("res aqib", res)
            if (res.status !== 200) {
                alert("Some thing went wrong...");
            }
            return res.json();
        })
        .then((response) => {
            console.log("pppppp", response);
            if(response.message=="Day Status Updated Successfully!"){
                window.location = "/dailysales"
            }
            else{
                alert("Something went wrong..")
            }
            setload(false)
        }).catch((error) => {
            console.log(error)
            alert("Please Check Your Internet Connection...")
            setload(false)
        })
      
    }
return ( 
      <>
      <div className="container my-5">
            <div className="row">
                  <div className="col-md-12">
                        <h1>Daily Sales Report</h1>
                        <div className='d-flex mt-3'>
                          <DateRangePicker onChange={(e)=>{
                            var temp = []
                            temp = [...e]
                            console.log("check date state", temp )
                            setdat(temp)
                            getAllSales(e,empId) 
                            }}  />
                        <select className='form-control ml-3' name="" id="" onChange={(e)=>{
                          console.log("employee",e.target.value)
                          setempId(e.target.value)
                          getAllSales(dat,e.target.value)
                          }}>
                          <option value="Select" selected>Select</option>
                          {
                                             props.allemployeeReducer&&props.allemployeeReducer.allemployee&&props.allemployeeReducer.allemployee.length>0?props.allemployeeReducer.allemployee.map(val=>(
                                          <option value={val.id}>{val.employeeName}</option>
                                              )):""
                          }
                        </select>
                        </div>
                  </div>
            </div>
            <div className='bg-white rounded shadow-lg p-lg-3 p-3 my-3'>
<div className="row">
<div className="col-md-6">
            {
               status!==null&&status!==undefined&&status!==""&&status!=="open"?
<Link><button className='btn btn-primary rounded mb-3 mt-4' disabled>Day Closed</button></Link>
:
<Link><button className='btn btn-primary rounded mb-3 mt-4' onClick={()=>daystatus()}>Day Closed</button></Link>
            }
            </div>
              <div className="col-md-6 text-right">
              <button className='btn btn-primary rounded mb-3 mt-4' onClick={handlePrint}>Print this out!</button>
              </div>
</div>
            <div ref={componentRef} style={{overflow:"auto",maxHeight:"500px"}}>
            <table className='table border-0  w-100' >
            <tr className='border-0 table-secondary'>
                   <th style={{border:"1px solid black"}}>Date</th>
                   {/* <th style={{border:"1px solid black"}}>Van</th> */}
                   <th style={{border:"1px solid black"}}>DSR No</th>
                   <th style={{border:"1px solid black"}}>DSR Amount</th>
                   <th style={{border:"1px solid black"}}>Cash</th>
                   <th style={{border:"1px solid black"}}>Cheque</th>
                   <th style={{border:"1px solid black"}}>Credit</th>
                   {/* <th style={{border:"1px solid black"}}>Bank Slip</th> */}
                   <th style={{border:"1px solid black"}}>Adjustment</th>
                   <th style={{border:"1px solid black"}}>Percentage Discount</th>
                   <th style={{border:"1px solid black"}}>Party Name</th>
                   <th style={{border:"1px solid black"}}>Shortage</th>
                   {/* <th style={{border:"1px solid black"}}>Remarks</th> */}
                   <th style={{border:"1px solid black"}}>Orderbooker</th>
                   <th style={{border:"1px solid black"}}>Salesman/action</th>
                   {/* <th style={{border:"1px solid black"}}>Action</th> */}
               </tr>
               {
                  oversales&&oversales.length>0?oversales.map(val=>(
                    <tr>
                    <td style={{border:"1px solid black"}}>{`${val.salesDate.split("T")[0]} ${Number(val.salesDate.split("T")[1].split(".")[0].split(":")[0])+5}:${val.salesDate.split("T")[1].split(".")[0].split(":")[1]}:${val.salesDate.split("T")[1].split(".")[0].split(":")[2]}`}</td>
                    {/* <td style={{border:"1px solid black"}}>{val.van}</td> */}
                    <td style={{border:"1px solid black"}}>{val.dsrNo}</td>
                    <td style={{border:"1px solid black"}}>{val.dsrAmount}</td>
                    <td style={{border:"1px solid black"}}>{val.cash}</td>
                    <td style={{border:"1px solid black"}}>{val.cheque}</td>
                    <td style={{border:"1px solid black"}}>{val.credit}</td>
                    {/* <td style={{border:"1px solid black"}}>{val.bankSlip}</td> */}
                    <td style={{border:"1px solid black"}}>{val.adjustment}</td>
                    <td style={{border:"1px solid black"}}>{val.percentageDiscount}</td>
                    <td style={{border:"1px solid black"}}>{val.percentageDiscountPartyName}</td>
                    <td style={{border:"1px solid black"}}>{val.shortage}</td>
                    {/* <td style={{border:"1px solid black"}}>{val.remarks}</td> */}
                    <td style={{border:"1px solid black"}}>{val.orderbooker.employeeName}</td>
                    <td style={{border:"1px solid black"}} className="text-center">{val.salesman.employeeName}<br />
                    {
                      status!=="open"&&status!==null&&status!==undefined&&status!==""&&status!=="open"&&ddd!==null&&ddd!==undefined&&ddd!==""&&ddd==val.salesDate.split("T")[0]?
                     <>
                      <Link ><button className='btn btn-sm btn-primary text-dark mt-2' disabled={true}><strong>Edit</strong></button></Link>
                      <button className='btn btn-sm btn-primary text-dark w-100 mt-2'  disabled={true}><strong>Closed</strong></button>
                     </>
                      :
                      <>
                       <Link to={val.salesStatus!=="open"?`/alldailysales`:`/editdailysales?id=${val.id}&date=${val.salesDate.split("T")[0]}`}><button className='btn btn-sm btn-primary text-dark mt-2' disabled={val.salesStatus!==null&&val.salesStatus!==undefined&&val.salesStatus!==""&&val.salesStatus!=="open"?true:false}><strong>Edit</strong></button></Link>
                     <button className='btn btn-sm btn-primary text-dark w-100 mt-2' onClick={()=>closedstatus(val.id,val.salesStatus)} disabled={val.salesStatus!=="open"?true:false}><strong>Closed</strong></button>
                      </>
                    }
                    </td>
                    {/* <td style={{borderRight:"1px solid black",display:"flex"}}></td> */}
                </tr>
                  )):"No Sales Found"
              }
              {
                   totsales&&totsales.length>0?totsales.map(tot=>(
                <>
                    <tr>
                    <td style={{border:"1px solid black"}} colSpan="5"><b>Cash in Hand</b></td>
                    <td style={{border:"1px solid black"}}>{tot.total_cash}</td>
                    <td style={{border:"1px solid black"}} colSpan="5"><b>Total Shortage/Access</b></td>
                    <td style={{border:"1px solid black"}}>{tot.total_amount-tot.total_cash-tot.total_credit-tot.total_cheque}</td>
                </tr>
                   <tr>
                   <td style={{border:"1px solid black"}} colSpan="11"><b>Total Amount</b></td>
                   <td style={{border:"1px solid black"}}>{tot.total_cash+tot.total_credit+tot.total_cheque}</td>
                  
               </tr>
                </>
                  )):""
              }
</table>
</div>
          
            </div>
            {load == false ? (
                    <></>
                  ) : (
                    <FullPageLoader />
                  )}
      </div>
      </>
); 
} 
  
const mapStateToProps = (state) => ({
    allemployeeReducer: state.allemployeeReducer,
    alldailysalesReducer: state.alldailysalesReducer,
  });
  
  const mapDispatchToProps = (dispatch) => ({
    getAllEmployee: () => dispatch(getAllEmployee()),
    // getAllDailySales: (date2,empid,todate) => dispatch(getAllDailySales(date2,empid,todate)),
    getAllDailySalesReport: (date2,empid,todate) => dispatch(getAllDailySalesReport(date2,empid,todate)),
  });
  export default connect(
    mapStateToProps,
    mapDispatchToProps
  )(ShowDailySales);