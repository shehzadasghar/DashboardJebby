
import React from 'react'; 
import "./Dailysalesreport.css"
import {Link} from "react-router-dom"
  
const DailySalesReport = () => { 
 
return ( 
      <>
      <div className="container my-5">
            <div className="row">
                  <div className="col-md-12">
                        <h1>Create Daily Sales Report</h1>
                  </div>
            </div>
            <div className='bg-white rounded shadow-lg p-5 my-3'>
            <div className="row">
                  <div className="col-md-6">
                        <label htmlFor=""><strong>Product Sold</strong></label>
                        <input type="text" className='form-control w-100' placeholder='Product Sold' />
                  </div>
                  <div className="col-md-6">
                  <label htmlFor=""><strong>Date</strong></label>
                  <input type="date" className='form-control w-100'  />
                  </div>
            </div>
            <div className="row mt-4">
                  <div className="col-md-6">
                  <label htmlFor=""><strong>Total Revenue</strong></label>
                        <input type="text" className='form-control w-100' placeholder='Total Revenue' />
                  </div>
                  <div className="col-md-6">
                  <label htmlFor=""><strong>Total Sale Cost</strong></label>
                  <input type="number" className='form-control w-100' placeholder='Total Sale Cost' />
                  </div>
            </div>
            <div className="row mt-4">
            <div className="col-md-6">
                  <label htmlFor=""><strong>Total Profit</strong></label>
                  <input type="text" className='form-control w-100' placeholder='Total Profit' />
                  </div>
            </div>
            <div className="row mt-5">
                  <div className="col-md-12 text-center">
                 <Link><button className='border-0 rounded py-2 px-5  btnorderbookersub' ><strong>Submit</strong></button></Link>
                  </div>
            </div>
            </div>
      </div>
      </>
); 
} 
  
export default DailySalesReport; 