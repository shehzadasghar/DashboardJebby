
import React from 'react'; 
import "./Createsalesman.css"
import {Link} from "react-router-dom"
  
const CreateSalesMan = () => { 
 
return ( 
      <>
      <div className="container my-5">
            <div className="row">
                  <div className="col-md-12">
                        <h1>Create Sales Man</h1>
                  </div>
            </div>
            <div className='bg-white rounded shadow-lg p-5 my-3'>
            <div className="row">
                  <div className="col-md-6">
                        <label htmlFor=""><strong>Name</strong></label>
                        <input type="text" className='form-control w-100' placeholder='Order Booker Name' />
                  </div>
                  <div className="col-md-6">
                  <label htmlFor=""><strong>Reference Number</strong></label>
                  <input type="text" className='form-control w-100' placeholder='Reference Name' />
                  </div>
            </div>
            <div className="row mt-4">
                  <div className="col-md-6">
                  <label htmlFor=""><strong>Phone Number</strong></label>
                        <input type="number" className='form-control w-100' placeholder='Phone Number' />
                  </div>
                  <div className="col-md-6">
                  <label htmlFor=""><strong>CNIC Number</strong></label>
                  <input type="number" className='form-control w-100' placeholder='CNIC' />
                  </div>
            </div>
            <div className="row mt-4">
                  <div className="col-md-6">
                  <label htmlFor=""><strong>Area Covered</strong></label>
                  <select name="" className='form-control' id="">
                             <option value="" selected>Select</option>
                             <option value="">Malir</option>
                             <option value="">Liyari</option>
                             <option value="">Korangi</option>
                       </select>
                  </div>
                  <div className="col-md-6">
                  <label htmlFor=""><strong>Address</strong></label>
                  <input type="text" className='form-control w-100' placeholder='Address' />
                  </div>
            </div>
            <div className="row mt-5">
                  <div className="col-md-12 text-center">
                 <Link><button className='border-0 rounded py-2 px-5  btnorderbookersub' ><strong>Submit</strong></button></Link>
                  </div>
            </div>
            </div>
      </div>
      </>
); 
} 
  
export default CreateSalesMan; 