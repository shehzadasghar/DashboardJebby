import React , {useState,useEffect,useRef} from 'react'; 
import "./Showallbouncecheckpayment.css"
import {Link} from "react-router-dom"
import Modal from "react-modal";
import {getAllBounce} from "../../actions/Allbounce"
import {connect} from "react-redux"
import FullPageLoader from "../fullpageloader/fullPageLoader";
import { DateRangePicker } from 'rsuite';
import 'rsuite/dist/rsuite.min.css'
import {useReactToPrint } from 'react-to-print';
const config = require('../../helpers/config.json');
  
const ShowAllBounceCheckPayment = (props) => { 
  const componentRef = useRef();
  const handlePrint = useReactToPrint({
    content: () => componentRef.current,
    documentTitle:"All Advance",
    pageStyle:"print",
  });
    var date2 = new Date().toISOString().substr(0, 10)
    const [RecoverymodalIsOpen, setRecoveryModalIsOpen] = useState(false);
    const[dated,setdated]=useState()
    const[date1,setdate1]=useState()
    const [load,setload]=useState(false)
    useEffect(async() => {
   
        await props.getAllBounce()
      },[]);
      const loadGetBounce = async (datee) =>{
        if(datee!==null&&datee!==undefined&&datee!==""){
          var okdateto=datee[0].toISOString().substr(0, 10)
          var okdatefrom=datee[1].toISOString().substr(0, 10)
          setdated(okdateto)
          setdate1(okdatefrom)
          await props.getAllBounce(okdateto,okdatefrom)
          return null;
        }
        else{
          await props.getAllBounce(okdateto,okdatefrom)
          return null;
        }
      }
    const [personname,setpersonname]=useState("")
    const [shopname,setshopname]=useState("")
    const [date,setdate]=useState("")
    const [amount,setamount]=useState()
    const [chequeNumber,setchequeNumber]=useState("")
    const [remarks,setremarks]=useState("")
    const createcheck = async() =>{
      if(personname==""){
        alert("enter person name...")
      }
      else if(shopname==""){
        alert("enter shop name...")
      }
      else if(amount==""){
        alert("enter amount...")
      }
      else if(remarks==""){
        alert("enter remarks...")
      }
      else{
      setload(true)
       await fetch(`${config['baseUrl']}/bounce/create`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json',"jwt_token":localStorage.getItem("token") },
            body: JSON.stringify({
                "partyName":`${personname},${shopname}`,
                 "date":new Date().toISOString().substr(0, 10),
                  "amount":Number(amount),
                  "chequeNumber":chequeNumber,
                  "remarks":remarks
            })
        })
        .then(res => {
            console.log("res aqib", res)
            if (res.status !== 200) {
                alert("Some thing went wrong...");
            }
            return res.json();
        })
        .then((response) => {
            console.log("pppppp", response);
            if(response.message=="Bounce Cheque entry Created"){
                window.location = "/bouncecheck"
            }
            else{
                alert("Something went wrong..")
            }
            setload(false)

        }).catch((error) => {
            console.log(error)
            alert("Please Check Your Internet Connection...")
            setload(false)
        })
      }
    }
 
return ( 
      <>
      <div className="container my-5">
            <div className="row">
                  <div className="col-md-6">
                        <h2>All Bounce Check Payments</h2>
                        <DateRangePicker onChange={(e)=>loadGetBounce(e)}  />
                  </div>
                  <div className="col-md-6 text-lg-right text-md-right mt-2">
                  <button className='border-0 rounded py-2 px-5  btnorderbookersub' onClick={() => setRecoveryModalIsOpen(true)} >Add New Bounce Check Payment</button>
                  </div>
            </div>
            <div className='bg-white rounded shadow-lg p-lg-5 p-3 my-3'>
            <button className='btn btn-primary rounded mb-3 mt-4' onClick={handlePrint}>Print this out!</button>
              <div ref={componentRef} style={{overflow:"auto",maxHeight:"500px"}}>
            <table className='table border-0  w-100' >
            <tr className='border-0 table-secondary'>
                   <th style={{border:"1px solid black"}}>Date & Time</th>
                   <th style={{border:"1px solid black"}}>Person</th>
                   <th style={{border:"1px solid black"}}>Shop</th>
                   <th style={{border:"1px solid black"}}>Check No</th>
                   <th style={{border:"1px solid black"}}>Amount</th>
                   <th style={{border:"1px solid black"}}>Description</th>
               </tr>
  {
                  props.allbounceReducer.allbounce&&props.allbounceReducer.allbounce.bounceCheques&&props.allbounceReducer.allbounce.bounceCheques.length>0?props.allbounceReducer.allbounce.bounceCheques.map(val=>(
                    <tr>
                    <td style={{border:"1px solid black"}}>{`${val.createdAt.split("T")[0]} ${val.createdAt.split("T")[1].split(".")[0]}`}</td>
                    <td style={{border:"1px solid black"}}>{val.partyName.split(",")[0]}</td>
                    <td style={{border:"1px solid black"}}>{val.partyName.split(",")[1]}</td>
                    <td style={{border:"1px solid black"}}>{val.chequeNumber}</td>
                    <td style={{border:"1px solid black"}}>{val.amount}</td>
                    <td style={{border:"1px solid black"}}>{val.remarks}</td>
                </tr>
                  )):"No Expense Found"
              }
</table>
</div>
            </div>
            {props.allbounceReducer.loading == true ? (
                    <></>
                  ) : (
                    <FullPageLoader />
                  )}
            {load == false ? (
                    <></>
                  ) : (
                    <FullPageLoader />
                  )}
      </div>


      <Modal
                isOpen={RecoverymodalIsOpen}
                onRequestClose={() => setRecoveryModalIsOpen(false)}
                style={{
                  overlay: {
                    position: "fixed",
                    top: 0,
                    left: 0,
                    right: 0,
                    bottom: 0,
                    backgroundColor: "rgba(0,0,0,0.4)",
                    zIndex: "1",
                  },
                  content: {
                    position: "absolute",
                    margin: "0 auto",
                    width: "650px",
                    height: "467px",
                    top: "60px",
                    left: "0",
                    right: "0",
                    bottom: "100px",
                    border: "1px solid #ccc",
                    background: "#fff",
                    borderRadius: "4px",
                    outline: "none",
                    padding: "20px",
                    boxShadow: "0 0 5px 5px #f2f2f2",
                    borderRadius: "20px",
                    background: "#fff",
                    border: "1px solid #fff",
                  },
                }}
              >
                  <div className="row">
                      <div className="col-md-12 text-center">
                          <h3><strong>Add Bounce Check Payment</strong></h3>
                      </div>
                  </div>
                <div className="row mt-4">
<div className="col-md-6">
    <label htmlFor=""><strong>Person Name</strong></label>
    <input type="text" onChange={(e)=>setpersonname(e.target.value)}  className='form-control w-100' placeholder='Person Name' />
</div>
<div className="col-md-6">
    <label htmlFor=""><strong>Shop Name</strong></label>
    <input type="text" onChange={(e)=>setshopname(e.target.value)} className='form-control w-100' placeholder='Person Name' />
</div>

                </div>
                <div className="row mt-4">
                <div className="col-md-6">
    <label htmlFor=""><strong>Date</strong></label> <br />
    <input type="text" value={new Date().toISOString().substr(0, 10)} className='form-control w-100' placeholder='Date' />
</div>
<div className="col-md-6">
    <label htmlFor=""><strong>Amount</strong></label>
    <input type="number" onChange={(e)=>setamount(e.target.value)} className='form-control w-100' placeholder='Amount' />
</div>
                </div>
                <div className="row mt-4">
                <div className="col-md-6">
    <label htmlFor=""><strong>Description</strong></label>
    <input type="text" onChange={(e)=>setremarks(e.target.value)} className='form-control w-100' placeholder='Description' />
</div>
<div className="col-md-6">
    <label htmlFor=""><strong>Check No</strong></label>
    <input 
      onKeyPress={(e) => {
        if (e.key === "Enter") {
          createcheck();
        }
      }}
    type="text" onChange={(e)=>setchequeNumber(e.target.value)} className='form-control w-100' placeholder='Check NO:' />
</div>
                </div>
                <div className="row mt-4">
                    <div className="col-md-12 text-center">
                    <button className='border-0 rounded py-2 px-5  btnorderbookersub' onClick={()=>createcheck()} ><strong>Add</strong></button>
                    </div>
                </div>
              </Modal>
      </>
); 
} 
  
const mapStateToProps = (state) => ({
    allbounceReducer: state.allbounceReducer,
  });
  
  const mapDispatchToProps = (dispatch) => ({
    getAllBounce: (date2,todate) => dispatch(getAllBounce(date2,todate)),
  });
  export default connect(
    mapStateToProps,
    mapDispatchToProps
  )(ShowAllBounceCheckPayment);