
import React , {useState} from 'react'; 
import "./showallwarehouse.css"
import {Link} from "react-router-dom"
import Modal from "react-modal";
  
const ShowAllWareHouse = () => { 
    const [WarehousemodalIsOpen, setWarehouseModalIsOpen] = useState(false);
    var date = new Date()
 
return ( 
      <>
      <div className="container my-5">
            <div className="row">
                  <div className="col-md-6">
                        <h1>All Warehouses</h1>
                  </div>
                  <div className="col-md-6 text-lg-right text-md-right mt-2">
                  <button className='border-0 rounded py-2 px-5  btnorderbookersub' onClick={() => setWarehouseModalIsOpen(true)} >Add New Warehouse</button>
                  </div>
            </div>
            <div className='bg-white rounded shadow-lg p-lg-5 p-3 my-3'>
           <table className='table border-0 table-responsive' style={{overflow:"auto",maxHeight:"500px"}}>
               <thead className='border-0 table-secondary'>
                   <th style={{border:"1px solid black"}}>Name</th>
                   <th style={{border:"1px solid black"}}>Location</th>
                   <th style={{border:"1px solid black"}}>Address</th>
                   <th style={{border:"1px solid black"}}>Contact info</th>
               </thead>
               <tr>
                   <td style={{border:"1px solid black"}}>Lrem Ipsum</td>
                   <td style={{border:"1px solid black"}}>dolor sit amet consecture</td>
                   <td style={{border:"1px solid black"}}>id cupidiate perspiciatis lorem</td>
                   <td style={{border:"1px solid black"}}>Lorem ipsum dolor sit amet consectetur adipisicing elit. Id cupiditate quos perspiciatis fugit, tempore rem illo placeat at dolorem, saepe nihil. Illum recusandae architecto voluptatum aspernatur magnam error ipsa aliquam!</td>
               </tr>
               <tr>
                   <td style={{border:"1px solid black"}}>Lrem Ipsum</td>
                   <td style={{border:"1px solid black"}}>dolor sit amet consecture</td>
                   <td style={{border:"1px solid black"}}>id cupidiate perspiciatis lorem</td>
                   <td style={{border:"1px solid black"}}>Lorem ipsum dolor sit amet consectetur adipisicing elit. Id cupiditate quos perspiciatis fugit, tempore rem illo placeat at dolorem, saepe nihil. Illum recusandae architecto voluptatum aspernatur magnam error ipsa aliquam!</td>
               </tr>
               <tr>
                   <td style={{border:"1px solid black"}}>Lrem Ipsum</td>
                   <td style={{border:"1px solid black"}}>dolor sit amet consecture</td>
                   <td style={{border:"1px solid black"}}>id cupidiate perspiciatis lorem</td>
                   <td style={{border:"1px solid black"}}>Lorem ipsum dolor sit amet consectetur adipisicing elit. Id cupiditate quos perspiciatis fugit, tempore rem illo placeat at dolorem, saepe nihil. Illum recusandae architecto voluptatum aspernatur magnam error ipsa aliquam!</td>
               </tr>
               <tr>
                   <td style={{border:"1px solid black"}}>Lrem Ipsum</td>
                   <td style={{border:"1px solid black"}}>dolor sit amet consecture</td>
                   <td style={{border:"1px solid black"}}>id cupidiate perspiciatis lorem</td>
                   <td style={{border:"1px solid black"}}>Lorem ipsum dolor sit amet consectetur adipisicing elit. Id cupiditate quos perspiciatis fugit, tempore rem illo placeat at dolorem, saepe nihil. Illum recusandae architecto voluptatum aspernatur magnam error ipsa aliquam!</td>
               </tr>
             <tr>
                   <td style={{border:"1px solid black"}}>Lrem Ipsum</td>
                   <td style={{border:"1px solid black"}}>dolor sit amet consecture</td>
                   <td style={{border:"1px solid black"}}>id cupidiate perspiciatis lorem</td>
                   <td style={{border:"1px solid black"}}>Lorem ipsum dolor sit amet consectetur adipisicing elit. Id cupiditate quos perspiciatis fugit, tempore rem illo placeat at dolorem, saepe nihil. Illum recusandae architecto voluptatum aspernatur magnam error ipsa aliquam!</td>
               </tr>
             <tr>
                   <td style={{border:"1px solid black"}}>Lrem Ipsum</td>
                   <td style={{border:"1px solid black"}}>dolor sit amet consecture</td>
                   <td style={{border:"1px solid black"}}>id cupidiate perspiciatis lorem</td>
                   <td style={{border:"1px solid black"}}>Lorem ipsum dolor sit amet consectetur adipisicing elit. Id cupiditate quos perspiciatis fugit, tempore rem illo placeat at dolorem, saepe nihil. Illum recusandae architecto voluptatum aspernatur magnam error ipsa aliquam!</td>
               </tr>
             <tr>
                   <td style={{border:"1px solid black"}}>Lrem Ipsum</td>
                   <td style={{border:"1px solid black"}}>dolor sit amet consecture</td>
                   <td style={{border:"1px solid black"}}>id cupidiate perspiciatis lorem</td>
                   <td style={{border:"1px solid black"}}>Lorem ipsum dolor sit amet consectetur adipisicing elit. Id cupiditate quos perspiciatis fugit, tempore rem illo placeat at dolorem, saepe nihil. Illum recusandae architecto voluptatum aspernatur magnam error ipsa aliquam!</td>
               </tr>
           </table>
            </div>
      </div>


      <Modal
                isOpen={WarehousemodalIsOpen}
                onRequestClose={() => setWarehouseModalIsOpen(false)}
                style={{
                  overlay: {
                    position: "fixed",
                    top: 0,
                    left: 0,
                    right: 0,
                    bottom: 0,
                    backgroundColor: "rgba(0,0,0,0.4)",
                    zIndex: "1",
                  },
                  content: {
                    position: "absolute",
                    margin: "0 auto",
                    width: "650px",
                    height: "367px",
                    top: "100px",
                    left: "0",
                    right: "0",
                    bottom: "100px",
                    border: "1px solid #ccc",
                    background: "#fff",
                    borderRadius: "4px",
                    outline: "none",
                    padding: "20px",
                    boxShadow: "0 0 5px 5px #f2f2f2",
                    borderRadius: "20px",
                    background: "#fff",
                    border: "1px solid #fff",
                  },
                }}
              >
                  <div className="row">
                      <div className="col-md-12 text-center">
                          <h3><strong>Add Warehouse</strong></h3>
                      </div>
                  </div>
                <div className="row mt-4">
<div className="col-md-6">
    <label htmlFor=""><strong>Name</strong></label>
    <input type="text" className='form-control' placeholder='Name' />
</div>
<div className="col-md-6">
    <label htmlFor=""><strong>Location</strong></label>
    <input type="text" className='form-control' placeholder='Location' />
</div>
                </div>
                <div className="row mt-4">
                <div className="col-md-6">
    <label htmlFor=""><strong>Address</strong></label>
    <input type="text" className='form-control' placeholder='Address' />
</div>
<div className="col-md-6">
    <label htmlFor=""><strong>Contact Info</strong></label>
    <input type="text" className='form-control' placeholder='Contact Info' />
</div>
                </div>
                <div className="row mt-4">
                    <div className="col-md-12 text-center">
                    <button className='border-0 rounded py-2 px-5  btnorderbookersub' onClick={() => setWarehouseModalIsOpen(false)} ><strong>Add</strong></button>
                    </div>
                </div>
              </Modal>
      </>
); 
} 
  
export default ShowAllWareHouse; 