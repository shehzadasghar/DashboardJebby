import React from "react"
import "./Footer.css"


const Footer = (props) => {
   
    return (
        <>
  <div className="footer py-2" style={{backgroundColor: 'rgb(0 0 0 / 95%)'}} id="footer">
        <div className="container">
          <div className="row pt-3">
            <div className="col-md-12 text-center">
              <p style={{color: 'white', marginBottom: '0px'}}><strong style={{color: '#2184d4'}}>Coderouting</strong> © 2020 All Rights
                Reserved</p>
            </div>
          </div>
        </div>
      </div>
        </>
    )
}
export default Footer