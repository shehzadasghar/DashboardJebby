
import React , {useState,useEffect,useRef} from 'react'; 
import "./Showallexpanse.css"
import {Link} from "react-router-dom"
import Modal from "react-modal";
import {getAllExpense} from "../../actions/Allexpense"
import {connect} from "react-redux"
import FullPageLoader from "../fullpageloader/fullPageLoader";
import { DateRangePicker } from 'rsuite';
import 'rsuite/dist/rsuite.min.css'
import {useReactToPrint } from 'react-to-print';
const config = require('../../helpers/config.json');
  
const ShowAllExpense = (props) => { 
  const componentRef = useRef();
  const handlePrint = useReactToPrint({
    content: () => componentRef.current,
    documentTitle:"All Advance",
    pageStyle:"print",
  });
    var date2 = new Date().toISOString().substr(0, 10)
    const [ExpensemodalIsOpen, setExpenseModalIsOpen] = useState(false);
    const[date,setdate]=useState()
    const[date1,setdate1]=useState()
  const [load,setload]=useState(false)
  useEffect(async() => {
   
    await props.getAllExpense()
  },[]);
  const loadGetRoles = async (datee) =>{
    if(datee!==null&&datee!==undefined&&datee!==""){
      var okdateto=datee[0].toISOString().substr(0, 10)
      var okdatefrom=datee[1].toISOString().substr(0, 10)
      setdate(okdateto)
      setdate1(okdatefrom)
      await props.getAllExpense(okdateto,okdatefrom)
      return null;
    }
    else{
      await props.getAllExpense(okdateto,okdatefrom)
      return null;
    }
  }
    const [expenseDate,setexpenseDate]=useState("")
    const [amount,setamount]=useState()
    const [description,setdescription]=useState("")
    const createexpense = async() =>{
      if(amount==""){
        alert("enter amount...")
      }
      else if(description==""){
        alert("enter description...")
      }
      else{
      setload(true)
       await fetch(`${config['baseUrl']}/expenses/createExpense`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json',"jwt_token":localStorage.getItem("token") },
            body: JSON.stringify({
                "expenseDate":new Date().toISOString().substr(0, 10),
                 "amount":Number(amount),
                  "description":description,
                  "distributionId":localStorage.getItem("disid"),
            })
        })
        .then(res => {
            console.log("res aqib", res)
            if (res.status !== 200) {
                alert("Some thing went wrong...");
            }
            return res.json();
        })
        .then((response) => {
            console.log("pppppp", response);
            if(response.message=="Expense Created"){
                window.location = "/Expense"
            }
            else{
                alert("Something went wrong..")
            }
            setload(false)

        }).catch((error) => {
            console.log(error)
            alert("Please Check Your Internet Connection...")
            setload(false)
        })
      }
    }
 
return ( 
      <>
      <div className="container my-5">
            <div className="row">
                  <div className="col-md-6">
                        <h1>All Expense</h1>
                        <DateRangePicker onChange={(e)=>loadGetRoles(e)}  />
                  </div>
                  <div className="col-md-6 text-lg-right text-md-right mt-2">
                  <button className='border-0 rounded py-2 px-5  btnorderbookersub' onClick={() => setExpenseModalIsOpen(true)} >Add New Expense</button>
                  </div>
            </div>
            <div className='bg-white rounded shadow-lg p-lg-5 p-3 my-3'>
            <button className='btn btn-primary rounded mb-3 mt-4' onClick={handlePrint}>Print this out!</button>
              <div ref={componentRef} style={{overflow:"auto",maxHeight:"500px"}}>
            <table className='table border-0  w-100' >
            <tr className='border-0 table-secondary'>
                   <th style={{border:"1px solid black"}}>Date & Time</th>
                   <th style={{border:"1px solid black"}}>Amount</th>
                   <th style={{border:"1px solid black"}}>Description</th>
               </tr>
  {
                  props.allexpenseReducer.allexpense&&props.allexpenseReducer.allexpense.expenses&&props.allexpenseReducer.allexpense.expenses.length>0?props.allexpenseReducer.allexpense.expenses.map(val=>(
                    <tr>
                    <td style={{border:"1px solid black"}}>{`${val.createdAt.split("T")[0]} ${val.createdAt.split("T")[1].split(".")[0]}`}</td>
                    <td style={{border:"1px solid black"}}>{val.amount}</td>
                    <td style={{border:"1px solid black"}}>{val.description}</td>
                </tr>
                  )):"No Expense Found"
              }
                <tr>
                <td style={{border:"1px solid black"}}><strong>Total Amount:</strong></td>
                    <td style={{border:"1px solid black"}} colSpan="2" className='text-center'><strong>{props.allexpenseReducer.allexpense&&props.allexpenseReducer.allexpense.totalExpenses&&props.allexpenseReducer.allexpense.totalExpenses.total_amount!==null&&props.allexpenseReducer.allexpense.totalExpenses.total_amount!==undefined&&props.allexpenseReducer.allexpense.totalExpenses.total_amount!==""?props.allexpenseReducer.allexpense.totalExpenses.total_amount:""}</strong></td>
                </tr>
</table>
</div>
            </div>
            {props.allexpenseReducer.loading == true ? (
                    <></>
                  ) : (
                    <FullPageLoader />
                  )}
                    {load == false ? (
                    <></>
                  ) : (
                    <FullPageLoader />
                  )}
      </div>


      <Modal
                isOpen={ExpensemodalIsOpen}
                onRequestClose={() => setExpenseModalIsOpen(false)}
                style={{
                  overlay: {
                    position: "fixed",
                    top: 0,
                    left: 0,
                    right: 0,
                    bottom: 0,
                    backgroundColor: "rgba(0,0,0,0.4)",
                    zIndex: "1",
                  },
                  content: {
                    position: "absolute",
                    margin: "0 auto",
                    width: "450px",
                    height: "467px",
                    top: "100px",
                    left: "0",
                    right: "0",
                    bottom: "100px",
                    border: "1px solid #ccc",
                    background: "#fff",
                    borderRadius: "4px",
                    outline: "none",
                    padding: "20px",
                    boxShadow: "0 0 5px 5px #f2f2f2",
                    borderRadius: "20px",
                    background: "#fff",
                    border: "1px solid #fff",
                  },
                }}
              >
                  <div className="row">
                      <div className="col-md-12 text-center">
                          <h3><strong>Add Expense</strong></h3>
                      </div>
                  </div>
                <div className="row mt-4">
<div className="col-md-6">
    <label htmlFor=""><strong>Date</strong></label> <br />
    <input type="text" value={new Date().toISOString().substr(0, 10)}  className='form-control w-100' />
</div>
<div className="col-md-6">
    <label htmlFor=""><strong>Amount</strong></label>
    <input type="number" onChange={e=>setamount(e.target.value)} className='form-control w-100' placeholder='Amount' />
</div>
                </div>
                <div className="row mt-4">
                    <div className="col-md-12">
                        <label htmlFor=""><strong>Description</strong></label>
                        <textarea 
                           onKeyPress={(e) => {
                            if (e.key === "Enter") {
                              createexpense();
                            }
                          }}
                        name="" onChange={e=>setdescription(e.target.value)} className='form-control w-100' id="" cols="30" rows="4" placeholder='Description'></textarea>
                    </div>
                </div>
                <div className="row mt-4">
                    <div className="col-md-12 text-center">
                    <button className='border-0 rounded py-2 px-5  btnorderbookersub' onClick={() => createexpense()} ><strong>Add</strong></button>
                    </div>
                </div>
              </Modal>
      </>
); 
} 

const mapStateToProps = (state) => ({
    allexpenseReducer: state.allexpenseReducer,
  });
  
  const mapDispatchToProps = (dispatch) => ({
    getAllExpense: (date2,todate) => dispatch(getAllExpense(date2,todate)),
  });
  export default connect(
    mapStateToProps,
    mapDispatchToProps
  )(ShowAllExpense);