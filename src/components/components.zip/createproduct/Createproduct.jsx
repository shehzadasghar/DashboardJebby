
import React from 'react'; 
import "./Createproduct.css"
import {Link} from "react-router-dom"
  
const CreateProduct = () => { 
 
return ( 
      <>
      <div className="container my-5">
            <div className="row">
                  <div className="col-md-12">
                        <h1>Create Product</h1>
                  </div>
            </div>
            <div className='bg-white rounded shadow-lg p-5 my-3'>
            <div className="row">
                  <div className="col-md-6">
                        <label htmlFor=""><strong>Product Name</strong></label>
                        <input type="text" className='form-control w-100' placeholder='Product Name' />
                  </div>
                  <div className="col-md-6">
                  <label htmlFor=""><strong>Product Id</strong></label>
                  <input type="text" className='form-control w-100' placeholder='Product Id' />
                  </div>
            </div>
            <div className="row mt-4">
                  <div className="col-md-6">
                  <label htmlFor=""><strong>Product Bar Code</strong></label>
                        <input type="file" className='form-control w-100' placeholder='Product Bar Code' />
                  </div>
                  <div className="col-md-6">
                  <label htmlFor=""><strong>Product Cost Price</strong></label>
                  <input type="number" className='form-control w-100' placeholder='Product Cost Price' />
                  </div>
            </div>
            <div className="row mt-4">
            <div className="col-md-6">
                  <label htmlFor=""><strong>Sale Price</strong></label>
                  <input type="text" className='form-control w-100' placeholder='Sale Price' />
                  </div>
                  <div className="col-md-6">
                  <label htmlFor=""><strong>Quantity</strong></label>
                       <select name="" className='form-control' id="">
                             <option value="" selected>Select</option>
                             <option value="">By Carton</option>
                             <option value="">By Box</option>
                             <option value="">By Piece</option>
                       </select>
                  </div>
            </div>
            <div className="row mt-4">
                  <div className="col-md-6">
                  <label htmlFor=""><strong>No Of Cartons</strong></label>
                        <input type="number" className='form-control w-100' placeholder='No Of Cartons' />
                  </div>
                  <div className="col-md-6">
                  <label htmlFor=""><strong>Purchase Date</strong></label>
                        <input type="date" className='form-control w-100' placeholder='Purchase Date' />
                  </div>
            </div>
            <div className="row mt-5">
                  <div className="col-md-12 text-center">
                 <Link><button className='border-0 rounded py-2 px-5  btnorderbookersub' ><strong>Submit</strong></button></Link>
                  </div>
            </div>
            </div>
      </div>
      </>
); 
} 
  
export default CreateProduct; 