import React from "react"
import CreateDailySales from "../components/createdailysales/Createdailysales"
import Footer from "../components/footer/Footer"
import SideBar from "../components/sidebar/Sidebar"


const DailySales = ()=>{
    return(
        <>
<div className="d-lg-flex d-md-none d-none">
<SideBar />
<CreateDailySales />
</div>
<div className="d-lg-none d-md-block d-block">
<SideBar />
<CreateDailySales />
</div>
<Footer />
</>
    )
}
export default DailySales