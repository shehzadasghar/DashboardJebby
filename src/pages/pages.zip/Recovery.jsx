import React from "react"
import Footer from "../components/footer/Footer"
import SideBar from "../components/sidebar/Sidebar"
import ShowAllRecovery from "../components/showallrecovery/Showallrecovery"


const Recovery = ()=>{
    return(
        <>
<div className="d-lg-flex d-md-none d-none">
<SideBar />
<ShowAllRecovery />
</div>
<div className="d-lg-none d-md-block d-block">
<SideBar />
<ShowAllRecovery />
</div>
<Footer />
</>
    )
}
export default Recovery