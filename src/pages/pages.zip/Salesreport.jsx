import React from "react"
import DailySalesReport from "../components/dailysalesreport/Dailysalesreport"
import Footer from "../components/footer/Footer"
import SideBar from "../components/sidebar/Sidebar"


const SalesReportDaily = ()=>{
    return(
        <>
<div className="d-lg-flex d-md-none d-none">
<SideBar />
<DailySalesReport />
</div>
<div className="d-lg-none d-md-block d-block">
<SideBar />
<DailySalesReport />
</div>
<Footer />
</>
    )
}
export default SalesReportDaily