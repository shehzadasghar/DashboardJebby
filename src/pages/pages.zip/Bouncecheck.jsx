import React from "react"
import Footer from "../components/footer/Footer"
import SideBar from "../components/sidebar/Sidebar"
import ShowAllBounceCheckPayment from "../components/bouncecheckpayment/Showallbouncecheckpayment"


const BounceCheck = ()=>{
    return(
        <>
<div className="d-lg-flex d-md-none d-none">
<SideBar />
<ShowAllBounceCheckPayment />
</div>
<div className="d-lg-none d-md-block d-block">
<SideBar />
<ShowAllBounceCheckPayment />
</div>
<Footer />
</>
    )
}
export default BounceCheck