import React from "react"
import CreateOrderBooker from "../components/createorderbooker/Createorderbooker"
import Footer from "../components/footer/Footer"
import SideBar from "../components/sidebar/Sidebar"


const OrderBooker = ()=>{
    return(
        <>
<div className="d-lg-flex d-md-none d-none">
<SideBar />
<CreateOrderBooker />
</div>
<div className="d-lg-none d-md-block d-block">
<SideBar />
<CreateOrderBooker />
</div>
<Footer />
</>
    )
}
export default OrderBooker