import React from "react"
import EditDailySales from "../components/createdailysales/Editdailysales"
import Footer from "../components/footer/Footer"
import SideBar from "../components/sidebar/Sidebar"


const DailySalesEdit = ()=>{
    return(
        <>
<div className="d-lg-flex d-md-none d-none">
<SideBar />
<EditDailySales />
</div>
<div className="d-lg-none d-md-block d-block">
<SideBar />
<EditDailySales />
</div>
<Footer />
</>
    )
}
export default DailySalesEdit