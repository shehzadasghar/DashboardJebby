import React from "react"
import Footer from "../components/footer/Footer"
import ShowAllDailySales from "../components/showalldailysales/Showalldailysales"
import SideBar from "../components/sidebar/Sidebar"


const ShowDailySales = ()=>{
    return(
        <>
<div className="d-lg-flex d-md-none d-none">
<SideBar />
<ShowAllDailySales />
</div>
<div className="d-lg-none d-md-block d-block">
<SideBar />
<ShowAllDailySales />
</div>
<Footer />
</>
    )
}
export default ShowDailySales