import React from "react"
import Registration from "../components/registration/Registration"
import Footer from "../components/footer/Footer"


const RegistrationFrom = ()=>{
    return(
        <>
<div style={{display:"flex"}}>
</div>
    <Registration />
    <Footer />
</>
    )
}
export default RegistrationFrom