import React from "react"
import ShowAllExpense from "../components/showallexpanse/Showallexpanse"
import Footer from "../components/footer/Footer"
import SideBar from "../components/sidebar/Sidebar"


const Expense = ()=>{
    return(
        <>
<div className="d-lg-flex d-md-none d-none">
<SideBar />
<ShowAllExpense />
</div>
<div className="d-lg-none d-md-block d-block">
<SideBar />
<ShowAllExpense />
</div>
<Footer />
</>
    )
}
export default Expense