import React from "react"
import Footer from "../components/footer/Footer"
import ShowDailySales from "../components/showalldailysales/Showdailysales"
import SideBar from "../components/sidebar/Sidebar"


const DailySalesReport = ()=>{
    return(
        <>
<div className="d-lg-flex d-md-none d-none">
<SideBar />
<ShowDailySales />
</div>
<div className="d-lg-none d-md-block d-block">
<SideBar />
<ShowDailySales />
</div>
<Footer />
</>
    )
}
export default DailySalesReport