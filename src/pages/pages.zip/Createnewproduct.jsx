import React from "react"
import CreateProduct from "../components/createproduct/Createproduct"
import Footer from "../components/footer/Footer"
import SideBar from "../components/sidebar/Sidebar"


const CreateNewProduct = ()=>{
    return(
        <>
<div className="d-lg-flex d-md-none d-none">
<SideBar />
<CreateProduct />
</div>
<div className="d-lg-none d-md-block d-block">
<SideBar />
<CreateProduct />
</div>
<Footer />
</>
    )
}
export default CreateNewProduct