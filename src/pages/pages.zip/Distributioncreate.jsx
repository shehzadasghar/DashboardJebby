import React from "react"
import CreateDistribution from "../components/craetedistribution/Createdistribution"
import Footer from "../components/footer/Footer"
import SideBar from "../components/sidebar/Sidebar"


const DistributionCreate = ()=>{
    return(
        <>
<div className="d-lg-flex d-md-none d-none">
<SideBar />
<CreateDistribution />
</div>
<div className="d-lg-none d-md-block d-block">
<SideBar />
<CreateDistribution />
</div>
<Footer />
</>
    )
}
export default DistributionCreate