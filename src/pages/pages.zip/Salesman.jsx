import React from "react"
import CreateSalesMan from "../components/createsalesman/Createsalesman"
import Footer from "../components/footer/Footer"
import SideBar from "../components/sidebar/Sidebar"


const SalesMan = ()=>{
    return(
        <>
<div className="d-lg-flex d-md-none d-none">
<SideBar />
<CreateSalesMan />
</div>
<div className="d-lg-none d-md-block d-block">
<SideBar />
<CreateSalesMan />
</div>

<Footer />
</>
    )
}
export default SalesMan