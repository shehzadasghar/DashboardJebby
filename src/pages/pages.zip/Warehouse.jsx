import React from "react"
import ShowAllWareHouse from "../components/warehouse/showallwarehouse"
import Footer from "../components/footer/Footer"
import SideBar from "../components/sidebar/Sidebar"


const WareHouse = ()=>{
    return(
        <>
<div className="d-lg-flex d-md-none d-none">
<SideBar />
<ShowAllWareHouse />
</div>
<div className="d-lg-none d-md-block d-block">
<SideBar />
<ShowAllWareHouse />
</div>
<Footer />
</>
    )
}
export default WareHouse